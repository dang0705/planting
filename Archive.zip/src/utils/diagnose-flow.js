function mapSeverityToHealthText(severity = 'medium') {
  const key = String(severity || '').toLowerCase()
  if (key === 'high') return '需要治疗'
  if (key === 'critical') return '严重问题'
  if (key === 'low') return '轻微问题'
  return '轻微问题'
}

export function getHealthClass(status) {
  const classes = {
    健康: 'bg-green-100 text-green-700 px-3 py-1 rounded-full',
    轻微问题: 'bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full',
    需要治疗: 'bg-orange-100 text-orange-700 px-3 py-1 rounded-full',
    严重问题: 'bg-red-100 text-red-700 px-3 py-1 rounded-full'
  }
  return classes[status] || classes['轻微问题']
}

export function formatCausalityItem(item) {
  if (!item) return ''
  return `${item?.causeProblemKey || 'unknown'} → ${item?.effectProblemKey || 'unknown'}`
}

function normalizeObservedSymptoms(observedSymptoms = []) {
  return (Array.isArray(observedSymptoms) ? observedSymptoms : [])
    .filter(item => item?.symptomKey)
    .map(item => ({
      symptomKey: item.symptomKey,
      symptomCn: item.symptomCn || item.displayTextCn || item.symptomKey,
      confidence: Number(item.confidence || 0),
      source: item.source || item.evidenceSource || 'mixed'
    }))
}

function normalizeRankings(rankings = []) {
  return (Array.isArray(rankings) ? rankings : [])
    .filter(item => item?.problemKey)
    .map((item, index) => {
      const weightedScore = Number(item.weightedScore ?? item.finalScore ?? 0)
      const baseScore = Number(item.baseScore ?? item.weightedScore ?? item.finalScore ?? 0)

      return {
        problemId: item.problemId || '',
        problemKey: item.problemKey,
        problemCn: item.problemCn || item.displayName || item.problemKey,
        role: item.role || item.problemRole || '',
        rankNo: Number(item.rankNo || index + 1),
        weightedScore,
        finalScore: Number(item.finalScore ?? weightedScore),
        baseScore
      }
    })
}

function normalizeProblemCausality(items = []) {
  return (Array.isArray(items) ? items : []).map(item => ({
    causeProblemKey: item?.causeProblemKey || item?.cause_problem_key || '',
    effectProblemKey: item?.effectProblemKey || item?.effect_problem_key || '',
    relationType: item?.relationType || item?.relation_type || '',
    relationStrength: Number(item?.relationStrength ?? item?.relation_strength ?? 0),
    note: item?.note || ''
  }))
}

function normalizeQuestions(questions = []) {
  return (Array.isArray(questions) ? questions : [])
    .filter(item => item?.questionId)
    .map(item => ({
      questionId: item.questionId,
      text: item.text || '',
      helpText: item.helpText || '',
      options: (Array.isArray(item.options) ? item.options : [])
        .filter(option => option?.optionId)
        .map(option => ({
          optionId: option.optionId,
          text: option.text || ''
        }))
    }))
}

export function normalizeDiagnosisResult(diagnosisResult, { images = [], plantName = '植物' } = {}) {
  const diagnosis = diagnosisResult || {}
  const stage = diagnosis.stage || 'followup'
  const followUps = normalizeQuestions(diagnosis.questions || diagnosis.followUps)
  const finalResult = diagnosis.finalResult || null
  const explanation = diagnosis.explanation || diagnosis.resultExplanation || {}
  const observedSymptoms = normalizeObservedSymptoms(
    diagnosis.observedSymptoms || diagnosis.symptoms
  )
  const rankings = normalizeRankings(diagnosis.rankings)
  const problemCausality = normalizeProblemCausality(diagnosis.problemCausality)

  const severity =
    finalResult?.severity ||
    diagnosis?.summaryCard?.severity ||
    'medium'

  return {
    diagnosisSessionId: diagnosis.diagnosisSessionId || '',
    roundId: diagnosis.roundId || 'round_1',
    stage,
    status: diagnosis.status || (stage === 'final' ? 'closed' : 'active'),
    plantName,
    scientificName: '待识别',
    healthStatusText: mapSeverityToHealthText(severity),
    mainIssueText:
      finalResult?.displayName ||
      diagnosis?.summaryCard?.title ||
      '待进一步确认',
    summaryText:
      finalResult?.summary ||
      diagnosis?.summaryCard?.subtitle ||
      '',
    followUps,
    followUpRequired: stage === 'followup' && followUps.length > 0,
    finalResult,
    contributingFactors: Array.isArray(diagnosis.contributingFactors)
      ? diagnosis.contributingFactors
      : [],
    intermediateStates: Array.isArray(diagnosis.intermediateStates)
      ? diagnosis.intermediateStates
      : [],
    nextSteps: Array.isArray(diagnosis.nextSteps) ? diagnosis.nextSteps : [],
    whatToAvoid: Array.isArray(diagnosis.whatToAvoid) ? diagnosis.whatToAvoid : [],
    problemCausality,
    rankings,
    observedSymptoms,
    treatmentText:
      explanation?.firstAid ||
      (Array.isArray(diagnosis.nextSteps)
        ? diagnosis.nextSteps.map(item => item?.text).filter(Boolean).join('\n')
        : ''),
    preventionText:
      explanation?.avoid ||
      (Array.isArray(diagnosis.whatToAvoid)
        ? diagnosis.whatToAvoid.filter(Boolean).join('\n')
        : ''),
    images
  }
}

export function createFollowUpAnswerMap(followUps = []) {
  const entries = {}
  for (const item of followUps || []) {
    if (!item?.questionId) continue
    entries[item.questionId] = ''
  }
  return entries
}

export function isFollowUpAnswerComplete(followUps = [], answerMap = {}) {
  const activeFollowUps = (followUps || []).filter(item => item?.questionId)
  if (!activeFollowUps.length) return false
  return activeFollowUps.every(item => Boolean(answerMap[item.questionId]))
}

export function buildFollowUpPayload(result, answerMap = {}) {
  const followUps = Array.isArray(result?.followUps) ? result.followUps : []

  return {
    diagnosisSessionId: result?.diagnosisSessionId || '',
    roundId: result?.roundId || '',
    answers: followUps
      .filter(item => item?.questionId && answerMap[item.questionId])
      .map(item => ({
        questionId: item.questionId,
        optionId: answerMap[item.questionId]
      }))
  }
}
