import { useMutation } from '@tanstack/vue-query'
import { requestDiagnoseSync } from '@/http-functions/diagnose/client'
import {
  buildDiagnosePayload,
  handleDiagnoseError,
  runDiagnoseSuccessCallbacks,
  validateDiagnoseInput
} from './shared'

export function useDiagnoseMutation() {
  return useMutation({
    mutationKey: ['diagnose', 'start'],
    mutationFn: async ({
      image,
      imageIds = [],
      description,
      plantId,
      observedSymptoms = [],
      onText,
      onFinish,
      onError,
      skipAuth = false
    } = {}) => {
      try {
        onText?.('思考中...', '思考中...')
        validateDiagnoseInput({ plantId, image, observedSymptoms })

        const normalizedResult = await requestDiagnoseSync(
          buildDiagnosePayload({
            plantId,
            image,
            imageIds,
            description,
            observedSymptoms,
            skipAuth
          })
        )

        return runDiagnoseSuccessCallbacks(normalizedResult, { onText, onFinish })
      } catch (error) {
        console.error('同步诊断失败:', error)
        return handleDiagnoseError(error, { onError })
      }
    }
  })
}
