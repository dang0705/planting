export function buildDiagnosePayload({
  plantId,
  image,
  imageIds = [],
  description,
  observedSymptoms = [],
  skipAuth = false,
  platform = 'wechat-mini-program'
}) {
  const normalizedImageIds = Array.isArray(imageIds)
    ? imageIds.filter(item => typeof item === 'string' && item.trim())
    : []

  return {
    plantId,
    skipAuth,
    imageIds: normalizedImageIds.length ? normalizedImageIds : image ? [image] : [],
    ...(image ? { image } : {}),
    ...(description ? { description } : {}),
    ...(Array.isArray(observedSymptoms) && observedSymptoms.length ? { observedSymptoms } : {}),
    clientContext: {
      source: 'DiagnosePopup',
      platform
    }
  }
}

function isValidDiagnoseImageReference(image) {
  const value = String(image || '').trim()

  if (!value) {
    return false
  }

  if (value.startsWith('data:image/')) {
    return true
  }

  if (/^https?:\/\//i.test(value) && !/^https?:\/\/tmp\//i.test(value)) {
    return true
  }

  return false
}

export function validateDiagnoseInput({ plantId, image, observedSymptoms = [] }) {
  if (!plantId) {
    throw new Error('缺少植物ID，无法进行诊断')
  }
  if (Array.isArray(observedSymptoms) && observedSymptoms.length) {
    return
  }
  if (!isValidDiagnoseImageReference(image)) {
    throw new Error('请先上传诊断图片')
  }
}

export function runDiagnoseSuccessCallbacks(normalizedResult, { onText, onFinish } = {}) {
  const summary =
    normalizedResult?.finalResult?.summary ||
    normalizedResult?.summaryCard?.subtitle ||
    normalizedResult?.summaryCard?.title ||
    '诊断已更新'
  onText?.(summary, summary)
  onFinish?.(normalizedResult)
  return normalizedResult
}

export function handleDiagnoseError(error, { onError } = {}) {
  onError?.(error)
  throw error
}

export function buildFollowUpMutationPayload({
  diagnosisSessionId,
  roundId,
  answers = []
}) {
  if (!diagnosisSessionId) {
    throw new Error('缺少诊断会话ID，无法继续问诊')
  }

  return {
    diagnosisSessionId,
    roundId,
    answers
  }
}
