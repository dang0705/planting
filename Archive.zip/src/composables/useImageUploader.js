import { computed, ref } from 'vue'

function createEntryId() {
  return `upload_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`
}

function normalizeSuffixes(suffix = []) {
  const values = Array.isArray(suffix) ? suffix : String(suffix || '').split(',')
  return values
    .map(item => String(item || '').trim().toLowerCase().replace(/^\./, ''))
    .filter(Boolean)
}

function normalizeCompressionQuality(compressionRate = 80) {
  const value = Number(compressionRate || 0)
  if (!Number.isFinite(value) || value <= 0) return 80
  if (value <= 1) return Math.max(1, Math.min(100, Math.round(value * 100)))
  return Math.max(1, Math.min(100, Math.round(value)))
}

function normalizeMaxSizeBytes(size = 5) {
  const value = Number(size || 0)
  if (!Number.isFinite(value) || value <= 0) return 0
  if (value <= 100) {
    return Math.round(value * 1024 * 1024)
  }
  return Math.round(value)
}

function getFileExtension(filePath = '') {
  const normalized = String(filePath || '').trim().split('?')[0]
  const match = normalized.match(/\.([a-zA-Z0-9]+)$/)
  return match ? String(match[1] || '').toLowerCase() : ''
}

function statFile(filePath) {
  return new Promise((resolve, reject) => {
    wx.getFileSystemManager().stat({
      path: filePath,
      success: res => resolve(res?.stats?.size || 0),
      fail: reject
    })
  })
}

function compressLocalImage(filePath, quality) {
  if (quality >= 100) {
    return Promise.resolve(filePath)
  }

  return new Promise(resolve => {
    wx.compressImage({
      src: filePath,
      quality,
      success: res => resolve(res?.tempFilePath || filePath),
      fail: () => resolve(filePath)
    })
  })
}

function chooseImages(count) {
  return new Promise((resolve, reject) => {
    uni.chooseImage({
      count,
      sizeType: ['compressed'],
      sourceType: ['camera', 'album'],
      success: res => resolve(Array.isArray(res?.tempFilePaths) ? res.tempFilePaths : []),
      fail: reject
    })
  })
}

export function useImageUploader({
  count = 5,
  size = 5,
  suffix = ['jpg', 'jpeg', 'png', 'webp'],
  compressionRate = 80,
  uploadExecutor,
  removeExecutor
} = {}) {
  const files = ref([])
  const maxCount = Math.max(1, Number(count || 1))
  const maxSizeBytes = normalizeMaxSizeBytes(size)
  const allowedSuffixes = normalizeSuffixes(suffix)
  const compressionQuality = normalizeCompressionQuality(compressionRate)

  const hasPendingUploads = computed(() =>
    files.value.some(item => item.status === 'queued' || item.status === 'uploading')
  )
  const hasUploadErrors = computed(() =>
    files.value.some(item => item.status === 'error')
  )
  const uploadedFiles = computed(() =>
    files.value.filter(item => item.status === 'success')
  )
  const allUploaded = computed(() =>
    files.value.length > 0 && files.value.every(item => item.status === 'success')
  )
  const remainingCount = computed(() => Math.max(0, maxCount - files.value.length))

  function patchFile(entryId, updater) {
    const index = files.value.findIndex(item => item.id === entryId)
    if (index < 0) return
    const current = files.value[index]
    files.value.splice(index, 1, {
      ...current,
      ...(typeof updater === 'function' ? updater(current) : updater)
    })
  }

  async function validateLocalFile(filePath) {
    const ext = getFileExtension(filePath)
    if (allowedSuffixes.length && (!ext || !allowedSuffixes.includes(ext))) {
      throw new Error(`仅支持 ${allowedSuffixes.join('/')}`)
    }

    const fileSize = await statFile(filePath)
    if (maxSizeBytes > 0 && fileSize > maxSizeBytes) {
      const maxSizeMB = (maxSizeBytes / 1024 / 1024).toFixed(0)
      throw new Error(`图片需小于 ${maxSizeMB}MB`)
    }

    return {
      filePath,
      ext: ext || 'jpg',
      fileSize
    }
  }

  async function uploadEntry(entryId, context = {}) {
    patchFile(entryId, {
      status: 'uploading',
      loading: true,
      error: ''
    })

    const current = files.value.find(item => item.id === entryId)
    if (!current) return

    try {
      const compressedPath = await compressLocalImage(current.localPath, compressionQuality)
      const uploaded = await uploadExecutor({
        filePath: compressedPath,
        originalPath: current.localPath,
        ext: current.ext,
        size: current.size,
        entryId,
        context
      })

      patchFile(entryId, {
        status: 'success',
        loading: false,
        error: '',
        uploaded
      })
    } catch (error) {
      patchFile(entryId, {
        status: 'error',
        loading: false,
        error: error?.message || '上传失败'
      })
    }
  }

  async function chooseAndUpload(context = {}) {
    if (typeof uploadExecutor !== 'function') {
      throw new Error('缺少 uploadExecutor')
    }
    if (remainingCount.value <= 0) {
      return []
    }

    const picked = await chooseImages(remainingCount.value)
    if (!picked.length) {
      return []
    }

    const prepared = await Promise.all(
      picked.map(async filePath => {
        try {
          const validated = await validateLocalFile(filePath)
          return { ok: true, ...validated }
        } catch (error) {
          return {
            ok: false,
            filePath,
            error: error?.message || '文件校验失败'
          }
        }
      })
    )

    const rejected = prepared.filter(item => !item.ok)
    if (rejected.length) {
      uni.showToast({
        title: rejected[0]?.error || '部分图片不可用',
        icon: 'none'
      })
    }

    const accepted = prepared.filter(item => item.ok)
    const entries = accepted.map(item => ({
      id: createEntryId(),
      localPath: item.filePath,
      previewUrl: item.filePath,
      ext: item.ext,
      size: item.fileSize,
      status: 'queued',
      loading: true,
      error: '',
      uploaded: null
    }))

    files.value.push(...entries)
    await Promise.all(entries.map(item => uploadEntry(item.id, context)))
    return entries
  }

  async function removeAt(index) {
    const target = files.value[index]
    if (!target) return

    files.value.splice(index, 1)

    if (typeof removeExecutor === 'function' && target.uploaded) {
      try {
        await removeExecutor(target.uploaded)
      } catch (error) {
        console.warn('清理已上传文件失败:', error)
      }
    }
  }

  async function reset() {
    const snapshot = [...files.value]
    files.value = []

    if (typeof removeExecutor !== 'function') {
      return
    }

    await Promise.all(
      snapshot
        .filter(item => item?.uploaded)
        .map(item =>
          removeExecutor(item.uploaded).catch(error => {
            console.warn('清理已上传文件失败:', error)
          })
        )
    )
  }

  return {
    files,
    remainingCount,
    hasPendingUploads,
    hasUploadErrors,
    uploadedFiles,
    allUploaded,
    chooseAndUpload,
    removeAt,
    reset
  }
}
