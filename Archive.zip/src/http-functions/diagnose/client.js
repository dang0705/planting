import { httpRequest } from '@/http-functions/core/httpRequest'

function isRetryableRequestError(error) {
  const message = String(error?.message || error || '').toLowerCase()
  return (
    message.includes('timeout') ||
    message.includes('timed out') ||
    message.includes('network error') ||
    message.includes('request:fail') ||
    message.includes('fail timeout')
  )
}

function normalizeRequestError(error, fallbackMessage) {
  const message = String(error?.message || error || '')
  if (/timeout|timed out|fail timeout/i.test(message)) {
    return new Error(`${fallbackMessage}，请求超时，请重试`)
  }
  return error instanceof Error ? error : new Error(fallbackMessage)
}

async function requestWithRetry(task, { retries = 1, fallbackMessage = '请求失败' } = {}) {
  let lastError = null

  for (let attempt = 0; attempt <= retries; attempt += 1) {
    try {
      return await task()
    } catch (error) {
      lastError = error
      if (attempt >= retries || !isRetryableRequestError(error)) {
        break
      }
    }
  }

  throw normalizeRequestError(lastError, fallbackMessage)
}

function unwrapResponseEnvelope(raw, fallbackMessage = '请求失败') {
  if (!raw || typeof raw !== 'object') {
    throw new Error('接口响应为空')
  }

  const code = Number(raw.code ?? 200)
  if (code !== 200) {
    throw new Error(raw.message || fallbackMessage)
  }

  return raw.data ?? null
}

function normalizeHistoryList(data) {
  if (!data || typeof data !== 'object') {
    return {
      items: [],
      page: 1,
      pageSize: 10,
      hasMore: false
    }
  }

  if (Array.isArray(data.items)) {
    return data
  }

  const list = Array.isArray(data.list) ? data.list : []
  return {
    ...data,
    items: list.map(item => ({
      historyId: item?._id || '',
      resultId: item?._id || '',
      createdAt: item?.createdAt || '',
      summary: {
        problemId: item?.topProblemKey || '',
        displayName: item?.mainIssue || '诊断记录',
        severity: item?.healthStatus === 'danger' ? 'high' : 'medium'
      }
    }))
  }
}

function normalizeHistoryDetail(detail) {
  if (!detail || typeof detail !== 'object') {
    return null
  }

  if (detail?.diagnosisSessionId && detail?.finalResult) {
    return detail
  }

  const diagnosisSessionId = detail._id || detail.diagnosisSessionId || ''
  const summary = String(detail.summary || '').trim()

  return {
    resultId: diagnosisSessionId,
    diagnosisSessionId,
    plantId: detail.plantId || detail.plantCatalogId || '',
    stage: detail.needsFollowUp ? 'followup' : 'final',
    status: detail.needsFollowUp ? 'active' : 'closed',
    finalResult: {
      problemId: detail.topProblemKey || '',
      displayName: detail.finalProblemCn || detail.topProblemKey || '待进一步确认',
      summary,
      severity: detail.healthStatus === 'danger' ? 'high' : 'medium',
      urgency: 'medium'
    },
    explanation: {
      whyItHappens: summary,
      whatToCheckNext: '',
      firstAid: detail.treatment || '',
      avoid: detail.prevention || ''
    },
    observedSymptoms: Array.isArray(detail.symptoms)
      ? detail.symptoms.map(item => ({
          symptomKey: item?.symptomKey || '',
          symptomCn: item?.symptomCn || item?.symptomKey || '',
          confidence: Number(item?.confidence || 0),
          source: item?.evidenceSource || 'history'
        }))
      : [],
    rankings: Array.isArray(detail.rankings)
      ? detail.rankings.map(item => ({
          problemKey: item?.problemKey || '',
          problemCn: item?.problemCn || item?.problemKey || '',
          weightedScore: Number(item?.weightedScore || 0),
          finalScore: Number(item?.weightedScore || 0),
          rankNo: Number(item?.rankNo || 0)
        }))
      : [],
    followUps: Array.isArray(detail.followUps)
      ? detail.followUps.map(item => ({
          questionId: item?.symptomKey || '',
          text: item?.questionText || '',
          helpText: item?.rationale || '',
          status: item?.status || 'pending',
          answerValue: item?.answerValue || ''
        }))
      : [],
    contributingFactors: [],
    intermediateStates: [],
    nextSteps: detail.treatment
      ? [{ stepId: 'step_1', text: detail.treatment }]
      : [],
    whatToAvoid: detail.prevention ? [detail.prevention] : [],
    timeline: {
      createdAt: detail.createdAt || ''
    }
  }
}

const startDiagnosisRequester = httpRequest({
  functionPath: 'diagnose-http/diagnosis/start',
  method: 'POST'
})

const answerDiagnosisRequester = httpRequest({
  functionPath: 'diagnose-http/diagnosis/answer',
  method: 'POST'
})

const resultDiagnosisRequester = httpRequest({
  functionPath: 'diagnose-http/diagnosis/result',
  method: 'GET'
})

const historyDiagnosisRequester = httpRequest({
  functionPath: 'diagnose-http/diagnosis/history',
  method: 'GET'
})

const feedbackDiagnosisRequester = httpRequest({
  functionPath: 'diagnose-http/diagnosis/feedback',
  method: 'POST'
})

export async function requestDiagnosisStart(payload) {
  const response = await requestWithRetry(
    () => startDiagnosisRequester({ payload, timeout: 25000 }),
    { retries: 1, fallbackMessage: '发起诊断失败' }
  )
  return unwrapResponseEnvelope(response?.data, '发起诊断失败')
}

export async function requestDiagnosisAnswer(payload) {
  const response = await requestWithRetry(
    () => answerDiagnosisRequester({ payload, timeout: 25000 }),
    { retries: 1, fallbackMessage: '提交问诊失败' }
  )
  return unwrapResponseEnvelope(response?.data, '提交问诊失败')
}

export async function requestDiagnosisResult(query) {
  const response = await resultDiagnosisRequester({
    query: {
      id: query?.id || query?.sessionId || query?.resultId || ''
    }
  })
  const data = unwrapResponseEnvelope(response?.data, '读取诊断结果失败')
  return normalizeHistoryDetail(data)
}

export async function requestDiagnosisHistory(query = {}) {
  const response = await historyDiagnosisRequester({ query })
  const data = unwrapResponseEnvelope(response?.data, '读取诊断历史失败')
  return normalizeHistoryList(data)
}

export async function requestDiagnosisFeedback(payload) {
  const response = await feedbackDiagnosisRequester({ payload })
  return unwrapResponseEnvelope(response?.data, '提交反馈失败')
}

// 兼容旧调用名：同步诊断即发起首轮诊断。
export async function requestDiagnoseSync(payload) {
  return requestDiagnosisStart(payload)
}

// 兼容旧调用名：当前协议无 SSE，回调一次进度文案后走同步接口。
export async function requestDiagnoseStream(payload, { onProgress } = {}) {
  onProgress?.('正在分析图片并生成问诊...')
  return requestDiagnosisStart(payload)
}

// 兼容旧调用名：follow-up 即提交问诊答案。
export async function requestDiagnoseFollowUp(payload) {
  return requestDiagnosisAnswer(payload)
}
