﻿<template>
  <uni-popup ref="popup" type="bottom" :safe-area="false" @change="handleChange">
    <view class="bg-white rounded-t-3xl" style="max-height: 85vh">
      <!-- 头部 -->
      <view class="flex items-center justify-between px-4 py-3 border-b border-gray-100">
        <text class="text-lg font-semibold text-gray-900">AI 诊断</text>
        <view class="w-8 h-8 flex items-center justify-center" @click="close">
          <text class="text-gray-400 text-2xl">×</text>
        </view>
      </view>

      <!-- 内容区域 -->
      <scroll-view scroll-y class="px-4 py-4" style="max-height: 75vh">
        <!-- 未诊断状态 -->
        <view v-if="!result">
          <!-- 上传区域 -->
          <view class="mb-4">
            <text class="block text-base font-semibold text-gray-900 mb-2">📸 拍摄植物照片</text>
            <text class="block text-xs text-gray-500 mb-3">建议拍摄 2-3 张不同角度的照片</text>

            <!-- 图片预览 -->
            <view class="grid grid-cols-3 gap-2 mb-2">
              <view
                v-for="(img, index) in imageFiles"
                :key="img.id"
                class="relative aspect-square bg-gray-100 rounded-xl overflow-hidden"
              >
                <image :src="img.previewUrl" class="w-full h-full" mode="aspectFill" />
                <view
                  v-if="img.loading"
                  class="absolute inset-0 bg-white/75 flex flex-col items-center justify-center"
                >
                  <view class="upload-spinner mb-2" />
                  <text class="text-[11px] text-[#2D6A4F] font-medium">上传中</text>
                </view>
                <view
                  v-else-if="img.status === 'error'"
                  class="absolute inset-x-0 bottom-0 bg-red-500/90 px-2 py-1"
                >
                  <text class="block text-[10px] text-white leading-tight">{{ img.error || '上传失败' }}</text>
                </view>
                <view
                  class="absolute top-1 right-1 bg-red-500 rounded-full w-5 h-5 flex items-center justify-center"
                  @click="removeImage(index)"
                >
                  <text class="text-white text-xs">×</text>
                </view>
              </view>

              <!-- 添加按钮 -->
              <view
                v-if="imageFiles.length < 5"
                class="aspect-square bg-gray-50 rounded-xl flex flex-col items-center justify-center border border-dashed border-gray-300"
                @click="chooseImage"
              >
                <text class="text-2xl text-gray-400 mb-0.5">+</text>
                <text class="text-[10px] text-gray-400">添加</text>
              </view>
            </view>

            <text class="block text-[10px] text-gray-400 text-center">{{ imageFiles.length }}/5 张</text>
            <text v-if="hasPendingUploads" class="block text-[10px] text-[#2D6A4F] text-center mt-1">
              图片上传中，全部处理完成后可开始诊断
            </text>
            <text v-else-if="hasUploadErrors" class="block text-[10px] text-red-500 text-center mt-1">
              存在上传失败的图片，请删除后重新添加
            </text>
          </view>

          <!-- 诊断按钮 -->
          <button
            class="w-full bg-primary text-white font-semibold py-3 rounded-xl"
            :class="{ 'opacity-50': !canStartDiagnose() }"
            :disabled="!canStartDiagnose()"
            @click="startDiagnose"
          >
            开始诊断
          </button>

          <!-- 提示 -->
          <view class="mt-3 bg-[#D8F3DC] rounded-xl p-3">
            <text class="block text-xs font-semibold text-primary mb-1">💡 拍摄技巧</text>
            <text class="block text-[10px] text-gray-700 leading-relaxed">
              • 光线充足，避免逆光\n• 拍摄病变部位特写\n• 包含整体植株照片
            </text>
          </view>
        </view>

        <!-- 诊断结果 -->
        <view v-if="result">
          <!-- 植物信息 -->
          <view class="bg-gray-50 rounded-xl p-3 mb-3">
            <view class="flex items-center mb-2">
              <text class="text-2xl mr-2">🌿</text>
              <view class="flex-1">
                <text class="block text-base font-semibold text-gray-900">{{ result.plantName }}</text>
                <text class="block text-xs text-gray-500">{{ result.scientificName || '学名未知' }}</text>
              </view>
            </view>

            <!-- 健康状态 -->
            <view class="flex items-center justify-between p-2 bg-white rounded-lg">
              <text class="text-xs font-semibold text-gray-700">健康状态</text>
              <view :class="getHealthClass(result.healthStatusText)">
                <text class="text-xs font-bold">{{ result.healthStatusText }}</text>
              </view>
            </view>
          </view>

          <view v-if="result.observedSymptoms?.length" class="mb-3">
            <text class="block text-sm font-semibold text-gray-900 mb-2">👀 观察到的症状</text>
            <view class="bg-gray-50 rounded-xl p-3 flex flex-wrap gap-2">
              <view
                v-for="item in result.observedSymptoms"
                :key="item.symptomKey"
                class="px-2.5 py-1 rounded-full bg-green-50 text-green-700 text-[11px]"
              >
                {{ item.symptomCn || item.symptomKey }}
              </view>
            </view>
          </view>

          <view v-if="result.mainIssueText || result.summaryText" class="mb-3">
            <text class="block text-sm font-semibold text-gray-900 mb-2">🧠 当前结论</text>
            <view class="bg-gray-50 rounded-xl p-3">
              <text class="block text-xs text-gray-800 mb-2">{{ result.mainIssueText }}</text>
              <text class="block text-xs text-gray-600 leading-relaxed whitespace-pre-line">{{
                result.summaryText
              }}</text>
            </view>
          </view>

          <view v-if="result.followUpRequired" class="mb-3">
            <text class="block text-sm font-semibold text-gray-900 mb-2">🩺 继续问诊</text>
            <view class="bg-gray-50 rounded-xl p-3">
              <view
                v-for="item in result.followUps"
                :key="item.questionId"
                class="mb-3 last:mb-0"
              >
                <text class="block text-xs font-semibold text-gray-800 mb-1">{{ item.text }}</text>
                <text class="block text-[10px] text-gray-500 mb-2">{{ item.helpText }}</text>
                <view class="flex flex-wrap gap-2">
                  <button
                    v-for="option in item.options"
                    :key="option.optionId"
                    class="flex-1 min-w-[88px] py-2 rounded-xl text-xs"
                    :class="
                      followUpAnswers[item.questionId] === option.optionId
                        ? 'bg-primary text-white'
                        : 'bg-white border border-gray-200 text-gray-700'
                    "
                    @click="setFollowUpAnswer(item.questionId, option.optionId)"
                  >
                    {{ option.text }}
                  </button>
                </view>
              </view>
              <button
                class="w-full mt-2 bg-primary text-white py-2.5 rounded-xl text-sm"
                :class="{ 'opacity-50': submittingFollowUp || !canSubmitFollowUps() }"
                :disabled="submittingFollowUp || !canSubmitFollowUps()"
                @click="submitFollowUps"
              >
                {{ submittingFollowUp ? '重新诊断中...' : '提交问诊并重新诊断' }}
              </button>
            </view>
          </view>

          <!-- 操作按钮 -->
          <view class="flex gap-2">
            <button
              class="flex-1 bg-white border border-primary text-primary font-semibold py-2.5 rounded-xl text-sm"
              @click="resetDiagnose"
            >
              重新诊断
            </button>
            <button class="flex-1 bg-primary text-white font-semibold py-2.5 rounded-xl text-sm" @click="close">
              完成
            </button>
          </view>
        </view>
      </scroll-view>
    </view>

    <!-- AI 流式诊断弹窗 -->
    <AIStreamDialog
      ref="aiStreamDialogRef"
      :visible="showAIDialog"
      title="AI 智能诊断"
      icon="🩺"
      loading-text="正在诊断植物健康..."
      confirm-text="查看诊断结果"
      @close="handleAIDialogClose"
      @confirm="handleAIDialogConfirm"
      @retry="handleAIRetry"
    />
  </uni-popup>
</template>

<script setup>
import { ref } from 'vue'
import { useUserStore } from '@/store/user.js'
import { useDiagnoseStore } from '@/store/diagnose.js'
import { useCloudImageUploader } from '@/composables/useCloudImageUploader'
import { useDiagnoseMutation } from '@/vue-query/diagnose/mutations/useDiagnoseMutation.js'
import { useDiagnoseFollowUpMutation } from '@/vue-query/diagnose/mutations/useDiagnoseFollowUpMutation.js'
import {
  normalizeDiagnosisResult,
  createFollowUpAnswerMap,
  isFollowUpAnswerComplete,
  buildFollowUpPayload,
  getHealthClass
} from '@/utils/diagnose-flow.js'
import AIStreamDialog from './AIStreamDialog.vue'

const props = defineProps({
  plantId: {
    type: [String, Number],
    default: ''
  },
  plantName: {
    type: String,
    default: ''
  },
  observedSymptoms: {
    type: Array,
    default: () => []
  }
})

const emit = defineEmits(['success', 'close'])

const userStore = useUserStore()
const diagnoseStore = useDiagnoseStore()

const popup = ref(null)
const result = ref(null)
const showAIDialog = ref(false)
const aiStreamDialogRef = ref(null)
const pendingDiagnosePayload = ref(null)
const followUpAnswers = ref({})
const submittingFollowUp = ref(false)
const diagnoseMutation = useDiagnoseMutation()
const followUpMutation = useDiagnoseFollowUpMutation()
const uploader = useCloudImageUploader({
  count: 5,
  size: 5,
  suffix: ['jpg', 'jpeg', 'png', 'webp'],
  compressionRate: 80
})
const imageFiles = uploader.files
const hasPendingUploads = uploader.hasPendingUploads
const hasUploadErrors = uploader.hasUploadErrors

function open() {
  popup.value?.open()
}

function close() {
  popup.value?.close()
}

function handleChange(e) {
  if (!e.show) {
    emit('close')
  }
}

async function chooseImage() {
  try {
    await uploader.chooseAndUpload({
      plantId: props.plantId,
      maxAge: 7200
    })
  } catch (error) {
    const message = String(error?.errMsg || error?.message || '')
    if (message.includes('cancel')) {
      return
    }

    console.error('选择图片失败:', error)
    uni.showToast({
      title: '选择图片失败，请重试',
      icon: 'none'
    })
  }
}

function removeImage(index) {
  uploader.removeAt(index)
}

async function startDiagnose() {
  const hasObservedSymptoms = Array.isArray(props.observedSymptoms) && props.observedSymptoms.length > 0
  const uploadedImageUrls = uploader.uploadedUrls.value

  if (imageFiles.value.length === 0 && !hasObservedSymptoms) {
    uni.showToast({ title: '请先添加照片', icon: 'none' })
    return
  }

  if (hasPendingUploads.value) {
    uni.showToast({ title: '请等待图片上传完成', icon: 'none' })
    return
  }

  if (uploadedImageUrls.length === 0 && !hasObservedSymptoms) {
    uni.showToast({ title: '请至少保留 1 张上传成功的图片', icon: 'none' })
    return
  }

  if (!userStore.canDiagnose) {
    uni.showModal({
      title: '提示',
      content: '免费诊断次数已用完，升级会员享受无限次诊断',
      confirmText: '升级会员',
      success: res => {
        if (res.confirm) {
          close()
          uni.switchTab({ url: '/pages/profile/profile' })
        }
      }
    })
    return
  }

  try {
    const imageUrls = hasObservedSymptoms ? [] : uploadedImageUrls

    const diagnosePayload = {
      image: imageUrls[0] || '',
      imageIds: imageUrls,
      plantId: props.plantId,
      plantName: props.plantName,
      observedSymptoms: hasObservedSymptoms ? props.observedSymptoms : [],
      description: `共上传 ${imageFiles.value.length} 张照片`
    }

    pendingDiagnosePayload.value = diagnosePayload
    showAIDialog.value = true
    await new Promise(resolve => setTimeout(resolve, 100))
    aiStreamDialogRef.value?.startStream()

    await diagnoseMutation.mutateAsync({
      ...diagnosePayload,
      onText: (text, fullText) => {
        aiStreamDialogRef.value?.setText(fullText)
      },
      onFinish: diagnosisResult => {
        aiStreamDialogRef.value?.finishStream(diagnosisResult)
        userStore.useAIQuota()
      },
      onError: error => {
        aiStreamDialogRef.value?.setError(error)
      }
    })
  } catch (error) {
    console.error('诊断失败:', error)
    uni.hideLoading()
    uni.showToast({ title: error?.message || '诊断失败，请重试', icon: 'none' })
  }
}

function handleAIDialogClose() {
  showAIDialog.value = false
}

function handleAIDialogConfirm(diagnosisResult) {
  if (diagnosisResult) {
    const previewImages = imageFiles.value.map(item => item.previewUrl).filter(Boolean)
    result.value = normalizeDiagnosisResult(diagnosisResult, {
      images: previewImages,
      plantName: props.plantName || '植物'
    })
    followUpAnswers.value = createFollowUpAnswerMap(result.value.followUps)

    diagnoseStore.addToHistory({
      images: previewImages,
      diagnosis: result.value,
      diagnosisId: result.value.diagnosisSessionId || ''
    })

    emit('success', result.value)
    uni.showToast({ title: result.value.followUpRequired ? '需要继续问诊' : '诊断完成', icon: 'success' })
  }
  showAIDialog.value = false
}

function handleAIRetry() {
  if (pendingDiagnosePayload.value) {
    aiStreamDialogRef.value?.startStream()

    const callbackOpts = {
      ...pendingDiagnosePayload.value,
      onText: (text, fullText) => {
        aiStreamDialogRef.value?.setText(fullText)
      },
      onFinish: diagnosisResult => {
        aiStreamDialogRef.value?.finishStream(diagnosisResult)
      },
      onError: error => {
        aiStreamDialogRef.value?.setError(error)
      }
    }

    diagnoseMutation.mutateAsync(callbackOpts)
  }
}

function setFollowUpAnswer(questionId, answerValue) {
  followUpAnswers.value = {
    ...followUpAnswers.value,
    [questionId]: answerValue
  }
}

function canStartDiagnose() {
  const hasObservedSymptoms = Array.isArray(props.observedSymptoms) && props.observedSymptoms.length > 0
  const hasImages = imageFiles.value.length > 0

  if (!hasImages && !hasObservedSymptoms) {
    return false
  }

  return !hasPendingUploads.value
}

function canSubmitFollowUps() {
  return isFollowUpAnswerComplete(result.value?.followUps || [], followUpAnswers.value)
}

async function submitFollowUps() {
  if (!result.value || !canSubmitFollowUps()) {
    return
  }

  submittingFollowUp.value = true
  try {
    const payload = buildFollowUpPayload(result.value, followUpAnswers.value)
    const rerunResult = await followUpMutation.mutateAsync({
      diagnosisSessionId: payload.diagnosisSessionId,
      roundId: payload.roundId,
      answers: payload.answers
    })

    const previewImages = imageFiles.value.map(item => item.previewUrl).filter(Boolean)
    result.value = normalizeDiagnosisResult(rerunResult, {
      images: previewImages,
      plantName: props.plantName || result.value.plantName || '植物'
    })
    followUpAnswers.value = createFollowUpAnswerMap(result.value.followUps)

    diagnoseStore.addToHistory({
      images: previewImages,
      diagnosis: result.value,
      diagnosisId: result.value.diagnosisSessionId || ''
    })
    emit('success', result.value)

    uni.showToast({
      title: result.value.followUpRequired ? '问诊已更新' : '诊断已收敛',
      icon: 'success'
    })
  } catch (error) {
    console.error('提交问诊失败:', error)
    uni.showToast({ title: error.message || '问诊失败，请重试', icon: 'none' })
  } finally {
    submittingFollowUp.value = false
  }
}

async function resetDiagnose() {
  await uploader.reset()
  result.value = null
  pendingDiagnosePayload.value = null
  followUpAnswers.value = {}
}

defineExpose({
  open,
  close
})
</script>

<style scoped>
.whitespace-pre-line {
  white-space: pre-line;
}

.upload-spinner {
  width: 18px;
  height: 18px;
  border-radius: 9999px;
  border: 2px solid rgba(45, 106, 79, 0.2);
  border-top-color: #2d6a4f;
  animation: spin 0.8s linear infinite;
}

@keyframes spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}
</style>
