# taxonomy / 诊断流重构前问题清单

更新日期：2026-04-05

## 第六轮复核结论（再次以 `当前正式基线文档清单_v1_2_修正版.md` 为准）

说明：

- 本轮重新执行了 A 类文件逐条存在性核对。
- 本轮结论优先级高于下方“第五轮复核结论”。
- 本轮重点确认：
  - 修正版清单是否已真正收口为可执行基线
  - 旧 Draft 架构稿是否仍处于 `docs/new-rules` 正式基线目录内

### 本轮总状态

- `Issue 1`：`已修复`
- `Issue 2-10`：`已修复`
- `Issue 11`：`已修复`

### Issue 1：正式基线清单与仓库实际文件不一致

状态：`已修复`

复核结果：

- 当前 A 类 26 项已全部在 `docs/new-rules` 中按同名命中。
- 上一轮未收口的几项已全部补齐或改名到位，包括：
  - `当前全部文档最高规格联动一致性总审查报告.md`
  - `第一版_数据映射_导入脚本方案_v1.md`
  - `genus_care_profile_review_report.md`
  - `属级养护基线表设计_v1_1_full_reviewed_final_标题版本已统一.md`
- 上一轮发现的 `属级养护基线表设计_v1_1_full_reviewed_final.md.md` 字面错误已消失。
- `3.1 必看` 中的 `第一版_数据映射_导入脚本方案_v1.md` 当前也已真实存在，因此“按本清单开工”不再被这条阻塞。

结论：

- 修正版清单当前已经达到“可直接执行的正式基线入口”标准。

### Issue 2-10：核心架构问题是否回退

状态：`已修复`

复核结果：

- 本轮未发现 `Issue 2-10` 对应 A 类文档出现回退。
- 继续维持“已修复”。

### Issue 11：`植物症状识别系统架构_v1.md` 当前容易误导后续重构

状态：`已修复`

复核结果：

- `植物症状识别系统架构_v1.md` 当前位于 `docs/`，不再位于 `docs/new-rules/` 正式基线目录内。
- 修正版清单继续明确：只有 A 类文件才可作为正式基线，draft 文件不得直接作为实现依据。

结论：

- 从“后续重构是否会被正式基线目录内旧 Draft 误导”的角度，这条问题已经关闭。
- 仍可补充提醒：该文件在 `docs/` 下仍是 `Draft v1` 且保留旧命名，但它已经不再属于正式基线入口问题。

## 第五轮复核结论（再次以 `当前正式基线文档清单_v1_2_修正版.md` 为准）

说明：

- 本轮重新执行了 A 类文件逐条存在性核对。
- 本轮结论优先级高于下方“第四轮复核结论”。
- 本轮重点关注上一轮遗留的 4 个未收口文件名是否已有对应落地文件。

### 本轮总状态

- `Issue 1`：`部分修复`
- `Issue 2-10`：`已修复`
- `Issue 11`：`部分修复`

### Issue 1：正式基线清单与仓库实际文件不一致

状态：`部分修复`

本轮变化：

- A 类 26 项里，仍有 22 项可直接在 `docs/new-rules` 中按同名命中。
- 上一轮列为“未找到同名文件”的 4 项，这一轮都找到了高度对应的真实候选文件：
  - 清单写 `当前全部文档最高规格联动一致性总审查报告.md`
  - 仓库实际是 `当前全部文档最高规格联动一致性总审查报告_重新生成版.md`
  - 清单写 `第一版_数据映射_导入脚本方案_v1.md`
  - 仓库实际是 `第一版_数据映射_导入脚本方案_v1_重新生成版.md`
  - 清单写 `genus_care_profile_review_report.md`
  - 仓库实际是 `genus_care_profile_review_report_重新生成版.md`
  - 清单写 `属级养护基线表设计_v1_1_full_reviewed_final.md.md`
  - 仓库实际是 `属级养护基线表设计_v1_1_full_reviewed_final_标题版本已统一.md`

新增回退：

- 修正版清单第 24 项目前写成了 `属级养护基线表设计_v1_1_full_reviewed_final.md.md`，这是清单文本本身新增的字面错误，不再只是“标题版本未统一”。

结论：

- 这条问题不再主要表现为“文档根本不存在”。
- 当前更准确的表述是：
  - 仓库里已经有大概率对应的实际文件
  - 但正式基线清单没有把这些映射关系显式收口为真实文件名
  - 因而“本修正版之后，正式基线清单应视为当前唯一可信入口”这句话仍然没有完全成立

### Issue 2-10：核心架构问题是否回退

状态：`已修复`

复核结果：

- 本轮未发现 `Issue 2-10` 对应 A 类文档出现回退。
- 继续沿用第四轮结论。

### Issue 11：`植物症状识别系统架构_v1.md` 当前容易误导后续重构

状态：`部分修复`

复核结果：

- 本轮未见新的回退。
- 由于修正版清单继续明确 Draft 文件不得作为正式基线，因此这条仍维持“部分修复”。
- 但该 Draft 文件仍留在同目录，且旧命名仍在，风险没有完全消除。

## 第四轮复核结论（以 `当前正式基线文档清单_v1_2_修正版.md` 为准）

说明：

- 本轮以 `当前正式基线文档清单_v1_2_修正版.md` 作为唯一入口重新复核。
- 本轮重点检查：
  - A 类文件是否真实存在
  - 清单是否真的消除了悬空引用
  - 修正版清单是否足以降低旧 Draft 文档的误导风险
- 本轮结论优先级高于下方“第三轮复核结论”。

### 本轮总状态

- `Issue 1`：`部分修复`
- `Issue 2-10`：`已修复`
- `Issue 11`：`部分修复`

### Issue 1：正式基线清单与仓库实际文件不一致

状态：`部分修复`

本轮变化：

- 修正版清单已经把诊断主链的大部分 A 类文件名收口到当前真实存在的“标题版本已统一”版本。
- 相比上一轮旧 `v1.2` 清单，悬空引用数量已明显下降。
- 当前 A 类 26 项中，22 项可直接在 `docs/new-rules` 中命中。

仍未闭合的点：

- 以下 A 类文件名仍未在仓库中找到同名文件：
  - `当前全部文档最高规格联动一致性总审查报告.md`
  - `第一版_数据映射_导入脚本方案_v1.md`
  - `genus_care_profile_review_report.md`
- 以下 A 类文件存在“清单名”和“仓库真实文件名”未收口的问题：
  - 清单写的是 `属级养护基线表设计_v1_1_full_reviewed_final.md`
  - 仓库真实存在的是 `属级养护基线表设计_v1_1_full_reviewed_final_标题版本已统一.md`
- `3.1 必看` 仍把 `第一版_数据映射_导入脚本方案_v1.md` 列为开发前必读文件，但该文件当前不存在，因此“让 Codex 能直接按本清单开工”仍未完全成立。

结论：

- 修正版清单已经明显优于旧版，可作为当前更可信的正式入口。
- 但它还没有真正达到文档自己声明的“把 A 类正式基线文件全部收口为当前真实存在的文件名 / 移除悬空引用”。

### Issue 2-10：核心架构问题是否回退

状态：`已修复`

复核结果：

- 本轮没有发现 `Issue 2-10` 对应的 A 类文档出现反向回退。
- 因此继续沿用第三轮“已修复”结论。

### Issue 11：`植物症状识别系统架构_v1.md` 当前容易误导后续重构

状态：`部分修复`

本轮变化：

- 修正版清单已明确：
  - A 类文件才是正式基线
  - `linked / additive / aligned / review / draft` 文件不得直接当正式基线
- 在这个前提下，`植物症状识别系统架构_v1.md` 作为 `Draft v1`，其误导风险已被正式基线清单部分隔离。

仍未闭合的点：

- `植物症状识别系统架构_v1.md` 文件本身仍然存在于同目录。
- 文件内容仍引用旧版基线与旧中枢命名，例如：
  - `symptom_problem_weights`
  - `genus_common_problems`
  - `problem_host_profiles`

结论：

- 从“正式入口治理”角度，这条问题已经比上一轮明显缓和。
- 但从“目录内历史文档仍可能被人误读”角度，这条问题还没有彻底关闭。

## 第三轮复核结论（基于本轮新增“开发收口版”文档）

说明：

- 本轮重点复核了：
  - `当前正式基线文档清单_v1_2.md`
  - `开发前阻断问题一次性收口裁决_v1.md`
  - `最终_SQL_制表方案_v1_3_完整最终版_开发收口版.md`
  - `第一版_SQL_表结构草案_v1_1_开发收口版.md`
  - `植物_Taxonomy_体系定义_v1_3_完整最终版_开发收口版.md`
  - `绿植诊断系统完整流程图_终极版_中文主导_v1_1_开发收口版.dot`
  - `绿植诊断系统完整流程图说明_终极版_中文主导_v1_1_开发收口版.md`
- 本轮结论优先级高于下方“第二轮复核结论”。
- 状态分为：
  - `已修复`
  - `部分修复`
  - `未修复`

### Issue 1：正式基线清单与仓库实际文件不一致

状态：`部分修复`

本轮变化：

- 新增了 `当前正式基线文档清单_v1_2.md`，并明确声明它是“当前唯一正式基线索引”。
- 清单开始引入新的开发收口版基线，例如：
  - `开发前阻断问题一次性收口裁决_v1.md`
  - `最终_SQL_制表方案_v1_3_完整最终版_开发收口版.md`
  - `第一版_SQL_表结构草案_v1_1_开发收口版.md`
  - `植物_Taxonomy_体系定义_v1_3_完整最终版_开发收口版.md`

仍未闭合的点：

- `当前正式基线文档清单_v1_2.md` 自身仍指向多份不存在的 A 类文件，包括但不限于：
  - `当前全部文档最高规格联动一致性总审查报告.md`
  - `核心数据结构_v1_6_完整最终版_开发收口版.md`
  - `运行时模型_v1_5_完整最终版_开发收口版.md`
  - `决策流_v1_4_完整最终版_开发收口版.md`
  - `统一术语表_v1_4_完整最终版_开发收口版.md`
  - `最小可用知识库_v1_3_完整最终版_开发收口版.md`
  - `准入与退役规则_v1_3_完整最终版_开发收口版.md`
  - `Taxonomy_Diagnosis_SQL_字段映射表_v1_1_完整最终版_开发收口版.md`
  - `第一版_数据映射_导入脚本方案_v1.md`
  - `属级养护基线表设计_v1_1_full_reviewed_final.md`
  - `genus_care_profile_review_report.md`
- 目录里还存在重复副本文件，例如 `plant_identity_master_and_name_normalization_rules_v1 (1).md` 与流程图 SVG 的 `(1)` 副本，容易继续制造引用噪声。

结论：

- 与第二轮相比，“旧缺文件”问题已明显改善，但 `v1.2` 这份新总索引仍未真正做到可完全执行。
- 当前最实际的阻塞不再是“概念没收口”，而是“唯一正式基线索引仍有悬空引用”。

### Issue 2：被视为前置完成的桥接文档当前缺失

状态：`已修复`

复核结果：

- `plant_identity_master_and_name_normalization_rules_v1.md` 存在且可用。
- `taxonomy_diagnosis_linkage_rules_v1.md` 存在且可用。

### Issue 3：静态 Taxonomy 对象里混入了会话态身份状态

状态：`已修复`

复核结果：

- `植物_Taxonomy_体系定义_v1_3_完整最终版_开发收口版.md` 已明确：
  - Taxonomy 静态层不承载当前会话的 `matched / weak_matched / unresolved`
  - `identity_resolution_status` 不属于 Taxonomy 静态主数据字段
  - 它只属于运行时身份解析记录

### Issue 4：属级养护基线第一阶段挂接键当前不自洽

状态：`已修复`

复核结果：

- `植物_Taxonomy_体系定义_v1_3_完整最终版_开发收口版.md` 新增了 `family_name_canonical`。
- `最终_SQL_制表方案_v1_3_完整最终版_开发收口版.md` 与 `第一版_SQL_表结构草案_v1_1_开发收口版.md` 已统一裁决：
  - 第一阶段正式挂接键 = `genus_name + family_name_canonical`

### Issue 5：`route hint` 只影响流程层，与流程图当前走法存在冲突

状态：`已修复`

复核结果：

- `开发前阻断问题一次性收口裁决_v1.md`
- `最终_SQL_制表方案_v1_3_完整最终版_开发收口版.md`
- `第一版_SQL_表结构草案_v1_1_开发收口版.md`
- `绿植诊断系统完整流程图说明_终极版_中文主导_v1_1_开发收口版.md`

均明确写死：

- 只要条目已被 `formally_admitted`，就先进入 `observed_evidence_set`
- route hint 只改变后续流程优先级，不改变事实层先落位

并且新 DOT 已改为：

- `mg1 -> rt1 -> rt7 -> rt2`
- 四个主动作都在 `rt7` 之后才进入各自分支

### Issue 6：运行时 8 大对象没有明确的正式持久化策略

状态：`已修复`

复核结果：

- `开发前阻断问题一次性收口裁决_v1.md` 与 `最终_SQL_制表方案_v1_3_完整最终版_开发收口版.md` 已给出第一版最小持久化策略：
  - 必须 SQL 化
  - 建议 SQL 化
  - 默认不强制 SQL 化，可先放内存 / cache / trace

说明：

- 这不是完整 runtime persistence 哲学。
- 但对“第一版开发是否可开工”这个问题，已经足够。

### Issue 7：“视觉调用批次”已被定义为正式对象，但没有对应主记录方案

状态：`已修复`

复核结果：

- `开发前阻断问题一次性收口裁决_v1.md` 与 `最终_SQL_制表方案_v1_3_完整最终版_开发收口版.md` 已正式新增：
  - `visual_call_batches`
- `第一版_SQL_表结构草案_v1_1_开发收口版.md` 已给出该表最小 DDL。

### Issue 8：AI 入口新增治理字段没有进入正式 SQL 方案，当前只停留在草案 DDL

状态：`已修复`

复核结果：

- `最终_SQL_制表方案_v1_3_完整最终版_开发收口版.md` 已正式冻结这些关键字段：
  - `taxonomy_match_status`
  - `identity_resolution_status`
  - `is_current_primary_identity`
  - `superseded_*`
  - `route_primary_action`
  - `top1_stability_score`
  - `top3_stability_score`
  - `long_tail_noise_flag`
  - `pattern_derivation_status`
  - `question_correction_scope`
- `第一版_SQL_表结构草案_v1_1_开发收口版.md` 已同步给出 DDL。

### Issue 9：`taxonomy_match_status` 与 `identity_resolution_status` 的边界当前不清晰

状态：`已修复`

复核结果：

- `开发前阻断问题一次性收口裁决_v1.md` 与 `最终_SQL_制表方案_v1_3_完整最终版_开发收口版.md` 已显式区分：
  - `taxonomy_match_status` = 某条原始识别名对 Taxonomy 的命中结果
  - `identity_resolution_status` = 该解析记录进入当前会话身份裁定后的最终状态

### Issue 10：`route_primary_action` 的 `hold_for_review` 枚举没有流程出口

状态：`已修复`

复核结果：

- `开发前阻断问题一次性收口裁决_v1.md`
- `最终_SQL_制表方案_v1_3_完整最终版_开发收口版.md`
- `第一版_SQL_表结构草案_v1_1_开发收口版.md`
- `绿植诊断系统完整流程图说明_终极版_中文主导_v1_1_开发收口版.md`

都已明确：

- 第一版删除 `hold_for_review`
- 第一版 `route_primary_action` 只保留：
  - `retake_first`
  - `ask_first`
  - `uncertain_prepare`
  - `standard_flow`

### Issue 11：`植物症状识别系统架构_v1.md` 当前容易误导后续重构

状态：`未修复`

复核结果：

- 文件仍然是 `Draft v1`
- 仍引用旧版基线
- 仍保留旧命名：
  - `symptom_problem_weights`
  - `genus_common_problems`
  - `problem_host_profiles`

结论：

- 虽然 `当前正式基线文档清单_v1_2.md` 已声明“Codex 开发只看 A 类文件”，这能降低误用概率。
- 但该 Draft 仍留在同目录中，且内容仍有明显旧中枢命名，误导风险没有真正消除。

## 第二轮复核结论（基于本轮更新后的 `docs/new-rules`）

说明：

- 本节用于对照本文下方原始 issue 清单，给出当前状态。
- 状态分为：
  - `已修复`
  - `部分修复`
  - `未修复`

### Issue 1：正式基线清单与仓库实际文件不一致

状态：`部分修复`

本轮变化：

- `diagnosis_hard_constraints_v2_4_20260404_121000.md`
- `diagnosis_outcome_layer_v1_2_full_final.md`
- `problem_taxonomy_v1_4_full_final.md`
- `plant_identity_master_and_name_normalization_rules_v1.md`
- `taxonomy_diagnosis_linkage_rules_v1.md`

这些原先缺失的 A 类文件现在已经存在。

仍未闭合的点：

- `当前正式基线文档清单_v1_1.md` 的 2.1 节仍未给出文件映射，且仓库中只看到 `新增属级养护基线联动后文档体系最高规格一致性总审查报告_重新生成版.md`，没有看到“当前全部文档最高规格联动一致性总审查报告（完整最终版）”与“绿植诊断系统总脑图（完整版）”的同名或明确映射文件。
- 2.6 节中的
  - `属级养护基线概念联动分析与文档增补建议_v1.md`
  - `genus_care_profile_review_report.md`
  仍未按清单中的文件名出现；当前只看到 `属级养护基线概念联动分析与文档增补建议_v1_重新生成版.md`，未看到 `genus_care_profile_review_report.md`。

### Issue 2：被视为前置完成的桥接文档当前缺失

状态：`已修复`

复核结果：

- `plant_identity_master_and_name_normalization_rules_v1.md` 已存在，且已明确主表边界、canonical identity、alias_type、merge / retire 规则。
- `taxonomy_diagnosis_linkage_rules_v1.md` 已存在，且已明确 identity / genus / family / unresolved / weak_matched 的挂接优先级与边界。

当前这条问题不再是“文件缺失”，后续只需继续关注这些桥接文档与上位文档是否保持一致。

### Issue 3：静态 Taxonomy 对象里混入了会话态身份状态

状态：`未修复`

复核结果：

- `植物_Taxonomy_体系定义_v1_2_完整最终版_标题版本已统一.md` 仍在 6.4 节保留 `identity_resolution_status` 作为 taxonomy “识别链字段”。
- 与此同时，`最终_SQL_制表方案_v1_2_完整最终版_标题版本已统一.md` 仍明确主数据表不得承载会话级 matched / unresolved。

结论：

- 新增桥接文档虽然强化了边界，但旧冲突仍在正式 taxonomy 文档中保留。

### Issue 4：属级养护基线第一阶段挂接键当前不自洽

状态：`未修复`

复核结果：

- `最终_SQL_制表方案_v1_2_完整最终版_标题版本已统一.md` 仍要求 `genus_care_profiles` 第一阶段按 `genus_name + family_name` 挂接。
- 但同文件冻结的 `plant_identity_entities` 最小字段仍是 `family_name_cn` / `family_name_en`，未冻结统一的 `family_name` 字段。

结论：

- 第一阶段 join key 仍然没有被正式收口。

### Issue 5：`route hint` 只影响流程层，与流程图当前走法存在冲突

状态：`未修复`

复核结果：

- `docs/new-rules` 内相关正文没有看到对该冲突的补充裁决。
- `docs/绿植诊断系统完整流程图_终极版_中文主导.dot` 仍保持旧走法：只有 `standard_flow` 会进入 `observed_evidence_set` 之前的主链，其他主动作直接去 `question_queue`。

结论：

- 规则与流程图仍未统一。

### Issue 6：运行时 8 大对象没有明确的正式持久化策略

状态：`未修复`

复核结果：

- 本轮没有发现新增的“运行时对象持久化裁决”文档。
- 也没有在 `docs/new-rules` 中看到对 `diagnostic_session` / `normalized_input` / `hypothesis_pool` / `outcome_pool` / `question_queue` / `stop_state` / `diagnostic_trace` 的 SQL / KV / cache / trace-only 分工说明。

结论：

- 运行时对象的持久化边界仍缺 authoritative 裁决。

### Issue 7：“视觉调用批次”已被定义为正式对象，但没有对应主记录方案

状态：`未修复`

复核结果：

- 仍然只看到 `visual_call_batch_id` 散落在各表 / 各对象中。
- 未看到 `visual_call_batches` 或等价的批次主记录方案。

结论：

- “正式对象”与“仅有 ID 字段”之间的缺口仍然存在。

### Issue 8：AI 入口新增治理字段没有进入正式 SQL 方案，当前只停留在草案 DDL

状态：`未修复`

复核结果：

- `route_primary_action`、`question_correction_scope`、`top1_stability_score`、`pattern_derivation_status` 等字段，仍主要只在 `第一版_SQL_表结构草案_v1.md` 和审查报告中有具体 DDL。
- `最终_SQL_制表方案_v1_2_完整最终版_标题版本已统一.md` 仍未把这些字段正式冻结进表级字段定义。

结论：

- 规则到正式 SQL 的字段收口仍未完成。

### Issue 9：`taxonomy_match_status` 与 `identity_resolution_status` 的边界当前不清晰

状态：`未修复`

复核结果：

- 本轮仍未发现独立文档或章节正式定义 `taxonomy_match_status` 的独立语义。
- 现有示例中，这两个字段仍然直接同值。

结论：

- 这两个状态字段仍存在重复建模风险。

### Issue 10：`route_primary_action` 的 `hold_for_review` 枚举没有流程出口

状态：`未修复`

复核结果：

- `hold_for_review` 仍保留在 AI 入口规范中。
- 流程图与示例链路仍没有对应出口或触发条件。

结论：

- 状态机仍未闭合。

### Issue 11：`植物症状识别系统架构_v1.md` 当前容易误导后续重构

状态：`未修复`

复核结果：

- 文件仍然是 `Draft v1`。
- 仍然引用旧版本基线。
- 仍然使用 `symptom_problem_weights`、`genus_common_problems`、`problem_host_profiles` 等旧中枢命名。
- 仍然要求后续再补两份配套文档后才能继续推进。

结论：

- 这份文件仍然更适合作为历史草案，而不是当前正式重构基线。

## 我当前理解的正式主链

1.  上游已被拆成两条并行链：
    
    -   身份链：百度植物识别 -> taxonomy 匹配 -> 当前会话主身份结果 -> 宿主先验输入。
    -   症状链：多图输入 -> 原始视觉记录 -> 标准化结果 -> 接纳判定 -> 正式证据 / 候选保留 / 路由建议。
2.  两条链在运行时前置阶段汇合：
    
    -   先形成 `normalized_input`
    -   再进入 `observed_evidence_set`
    -   再经过 `hypothesis_pool` / `outcome_pool` / `question_queue` / `stop_state` / `diagnostic_trace`
3.  静态知识层当前至少分四块：
    
    -   Taxonomy 主数据层
    -   Diagnosis 静态业务层
    -   Taxonomy -> Diagnosis 挂接层
    -   运行时与监督层
4.  最终输出空间不是 problem taxonomy 本身，而是 outcome layer：
    
    -   问题性结论
    -   非问题性结论
    -   不确定结论
5.  属级养护基线已经被放到 Taxonomy 侧：
    
    -   它不是 problem / outcome 主竞争对象
    -   只应在 explanation、环境偏离判断、动作建议阶段被消费

---

## P0：重构前必须先统一的问题

### 1. 正式基线清单与仓库实际文件不一致

问题：

-   `docs/new-rules/当前正式基线文档清单_v1_1.md:41-44` 列出两份“总审查报告”和一份“绿植诊断系统总脑图（完整版）”，但 `docs/new-rules` 目录下看不到这些正式文件。
-   同一清单在 `:55-60` 使用了 `diagnosis_hard_constraints_v2_4_20260404_121000.md`、`diagnosis_outcome_layer_v1_2_full_final.md`、`problem_taxonomy_v1_4_full_final.md`，但当前仓库实际存在的是中文命名版本。
-   同一清单在 `:85-104` 还列出多份实际缺失文件。

风险：

-   后续任何人按“正式基线清单”去引用文档，都会直接引用到不存在或未对齐的文件名。
-   “流程图 / 脑图”当前也存在命名漂移：清单写的是“总脑图”，仓库实际是 `绿植诊断系统完整流程图_终极版_中文主导.svg/.dot`。

建议：

-   先修正文档清单，使它只指向仓库中真实存在且当前认可的文件。
-   若存在“同物异名”，需要在清单中明确 alias 或 replaced-by 关系。

### 2. 被视为前置完成的桥接文档当前缺失

问题：

-   `docs/new-rules/当前正式基线文档清单_v1_1.md:85-88` 把《植物身份主表与命名归一规则 v1》《Taxonomy 与 Diagnosis 挂接规则 v1》列为正式基线。
-   `docs/new-rules/最终_SQL_制表方案_v1_2_完整最终版_标题版本已统一.md:9-12` 把这两份桥接文档写成已完成前提。
-   `docs/new-rules/Taxonomy_Diagnosis_SQL_字段映射表_v1_1_完整最终版_标题版本已统一.md:378-380` 又把它们写成落地前置顺序。
-   当前仓库中这两份文件并不存在。

风险：

-   现在的 SQL 方案、字段映射、taxonomy 文档都在引用一组并不存在的“桥接层裁决”。
-   这意味着 taxonomy 命名归一规则和 Taxonomy -> Diagnosis 挂接规则实际上没有独立 authoritative 文档。

建议：

-   要么补齐这两份桥接文档。
-   要么明确声明它们已被哪些现有文档吸收替代，并同步改写所有引用。

### 3. 静态 Taxonomy 对象里混入了会话态身份状态

问题：

-   `docs/new-rules/植物_Taxonomy_体系定义_v1_2_完整最终版_标题版本已统一.md:462-469` 把 `identity_resolution_status` 放进了 taxonomy 的“识别链字段”。
-   但 `docs/new-rules/最终_SQL_制表方案_v1_2_完整最终版_标题版本已统一.md:264-272` 明确规定主数据表不得承载会话级状态，且 `plant_identity_entities` 不记录某次会话的 matched / unresolved。
-   `docs/new-rules/核心数据结构_v1_6_完整最终版_标题版本已统一.md:570-592` 也已把 matched / weak_matched / unresolved 放进 `plant_identity_resolution_record` 这种运行时对象。
-   `docs/new-rules/诊断系统硬约束清单_v2_4_full_final.md:872-889` 同样把 unresolved 视为当前会话状态，而不是正式植物身份对象属性。

风险：

-   静态主数据和运行时状态被写混。
-   实现时极容易把 `identity_resolution_status` 错写到 `plant_identity_entities`，污染主数据层。

建议：

-   从 taxonomy 主对象字段定义里移除 `identity_resolution_status`。
-   明确它只属于 `plant_identity_resolution_record(s)` 或同级运行时对象。

### 4. 属级养护基线第一阶段挂接键当前不自洽

问题：

-   `docs/new-rules/最终_SQL_制表方案_v1_2_完整最终版_标题版本已统一.md:679-681` 规定第一阶段 `genus_care_profiles` 的正式业务挂接键是 `genus_name + family_name`。
-   `docs/new-rules/属级养护基线表设计_v1_1_full_reviewed_final_标题版本已统一.md:160-189` 也把 `genus_name + family_name` 作为业务唯一性。
-   但 `docs/new-rules/最终_SQL_制表方案_v1_2_完整最终版_标题版本已统一.md:451-473` 冻结的 `plant_identity_entities` 字段却是 `family_name_cn` / `family_name_en`，没有统一定义的 `family_name`。

风险：

-   第一阶段 join key 无法无歧义落地。
-   实现时会临时选择中文科名、英文科名或另造归一字段，导致后续数据漂移。

建议：

-   明确第一阶段挂接到底使用 `family_name_cn`、`family_name_en`，还是新增统一 `family_name` 归一字段。
-   不要把 join key 留给实现阶段临时拍板。

### 5. `route hint` 只影响流程层的规则，与流程图当前走法存在冲突

问题：

-   `docs/new-rules/ai_visual_to_diagnosis_runtime_linkage_example_v1_1_full_reviewed_final_标题版本已统一.md:236-245` 明确说 route hint 只影响 `question_queue`，不反写事实层。
-   `docs/new-rules/诊断系统硬约束清单_v2_4_full_final.md:650-658` 也明确说 route hint 只能影响流程与优先级，不得反写事实层。
-   但 `docs/绿植诊断系统完整流程图_终极版_中文主导.dot:229-239` 把 `route_primary_action` 放在建立 `observed_evidence_set` 之前；`retake_first` / `ask_first` / `uncertain_prepare` 三个分支都会直接走向 `q1`，只有 `standard_flow` 才会去 `rt7 -> rt8 -> lk1`。
-   `docs/new-rules/决策流_v1_4_完整最终版_标题版本已统一.md:498-520` 又要求回答回流必须先更新 `observed_evidence_set`，禁止绕过 evidence set。

风险：

-   按流程图实现时，非 `standard_flow` 分支可能会跳过正式证据构建，等于 route hint 实际改变了事实层写入顺序。
-   这和正文里的硬约束不是一回事。

建议：

-   明确：即使 `ask_first` / `retake_first`，是否仍应先把已正式接纳的条目落进 `observed_evidence_set`。
-   如果答案是“要”，则流程图需要调整。
-   如果答案是“不要”，则必须修改正文约束，说明 route hint 何时可以延迟事实层落位。

---

## P1：高优先级规范缺口

### 6. 运行时 8 大对象没有明确的正式持久化策略

问题：

-   `docs/new-rules/运行时模型_v1_5_完整最终版_标题版本已统一.md:159-168` 定义了 8 个核心会话对象：
    -   `diagnostic_session`
    -   `normalized_input`
    -   `observed_evidence_set`
    -   `hypothesis_pool`
    -   `outcome_pool`
    -   `question_queue`
    -   `stop_state`
    -   `diagnostic_trace`
-   但 `docs/new-rules/最终_SQL_制表方案_v1_2_完整最终版_标题版本已统一.md:126-145` 和 `:522-532` 的运行时层只给出了身份/视觉监督相关表。

风险：

-   运行时对象究竟哪些进库、哪些只驻留内存、哪些写缓存、哪些只留轨迹，目前没有 authoritative 策略。
-   一旦后端开始实现，会话态对象极容易被随意裁剪。

建议：

-   单独补一份“运行时对象持久化裁决”。
-   至少明确每个运行时对象的存储形态：SQL / KV / cache / trace-only / not persisted。

### 7. “视觉调用批次”已被定义为正式对象，但没有对应主记录方案

问题：

-   `docs/new-rules/ai_visual_entry_data_structure_and_retention_spec_v1_4_full_consolidated.md:523-566` 明确把“视觉调用批次”升级成正式对象，并要求相关对象统一带 `visual_call_batch_id`。
-   但 `docs/new-rules/最终_SQL_制表方案_v1_2_完整最终版_标题版本已统一.md:126-145` 并没有为 visual call batch 定义单独主表或主记录对象。
-   当前只有 `第一版_SQL_表结构草案_v1` 在若干表中散落 `visual_call_batch_id`，没有 batch 主记录。

风险：

-   概念上它是“正式对象”，实现上却只是一个分布式外键字符串。
-   这样无法稳定承载 batch 级元信息，例如：
    -   触发来源
    -   所属 round
    -   创建时间
    -   提交批次摘要
    -   批次级失败状态

建议：

-   明确 visual call batch 只是逻辑 ID，还是需要正式主表 / 主记录。
-   若是正式对象，建议补 `visual_call_batches` 或等价主记录方案。

### 8. AI 入口新增治理字段没有进入正式 SQL 方案，当前只停留在草案 DDL

问题：

-   AI 视觉入口规范新增了多批关键治理字段：
    -   `visual_call_batch_id`：`ai_visual_entry...md:561-566`
    -   `is_current_primary_identity` / `superseded_*`：`ai_visual_entry...md:581-647`
    -   `question_correction_scope`：`ai_visual_entry...md:682-690`
    -   `route_primary_action`：`ai_visual_entry...md:751-764`
    -   `top1_stability_score` / `top3_stability_score` / `long_tail_noise_flag` / `pattern_derivation_status`：`ai_visual_entry...md:772-803`
-   这些字段在 `docs/new-rules/第一版_SQL_表结构草案_v1.md:323-444` 有较具体的 DDL 映射。
-   但 `第一版_SQL_表结构草案_v1.md` 又不在当前正式基线清单里。
-   正式的《最终 SQL 制表方案》只冻结到了表级，没有把这些字段正式收口。

风险：

-   当前唯一“可编码”的字段方案存在于非基线草案里。
-   正式文档层没有完成从规则到字段的收口。

建议：

-   把 AI 入口新增字段正式升级进《最终 SQL 制表方案》或独立“运行时表字段冻结文档”。
-   不要继续依赖 `第一版_SQL_表结构草案_v1` 作为隐性事实来源。

### 9. `taxonomy_match_status` 与 `identity_resolution_status` 的边界当前不清晰

问题：

-   `docs/new-rules/ai_visual_entry_data_structure_and_retention_spec_v1_4_full_consolidated.md:581-584` 同时保留 `taxonomy_match_status` 与 `identity_resolution_status`，但没有明确区分语义。
-   `docs/new-rules/ai_visual_to_diagnosis_runtime_linkage_example_v1_1_full_reviewed_final_标题版本已统一.md:82-86` 里两者直接同值。
-   当前能看到的正式说明只对 `identity_resolution_status` 给了“身份链状态”含义，`taxonomy_match_status` 缺少独立裁定定义。

风险：

-   实现时这两个字段很可能重复存同一件事。
-   或者不同开发者各自赋予不同意义，导致状态漂移。

建议：

-   明确区分：
    -   `taxonomy_match_status` 是否只表达“本条原始识别名对 taxonomy 的命中结果”
    -   `identity_resolution_status` 是否表达“当前解析记录进入会话身份裁定后的最终状态”
-   如果本质没有区别，应删掉其中一个。

### 10. `route_primary_action` 的 `hold_for_review` 枚举没有流程出口

问题：

-   `docs/new-rules/ai_visual_entry_data_structure_and_retention_spec_v1_4_full_consolidated.md:759-764` 为 `route_primary_action` 增加了 `hold_for_review`。
-   但 `docs/绿植诊断系统完整流程图_终极版_中文主导.dot:99-103` 只画了四个分支：
    -   `retake_first`
    -   `ask_first`
    -   `uncertain_prepare`
    -   `standard_flow`
-   示例文档当前也只展示了 `ask_first` 和 `retake_first`，没有 `hold_for_review` 的合法触发条件和去向。

风险：

-   枚举已存在，但状态机未闭合。

建议：

-   要么删除 `hold_for_review`。
-   要么补充：
    -   触发条件
    -   流程出口
    -   是否进入 `question_queue`
    -   是否要求人工审查 / 人工确认

---

## P2：文档治理与误用风险

### 11. `植物症状识别系统架构_v1.md` 当前容易误导后续重构

问题：

-   文件本身是 Draft：`docs/new-rules/植物症状识别系统架构_v1.md:1-6`
-   它引用的是旧版本基线：`docs/new-rules/植物症状识别系统架构_v1.md:54-60`
-   它还使用当前正式文档链中没有继续作为核心中枢表出现的旧命名：
    -   `symptom_problem_weights`
    -   `genus_common_problems`
    -   `problem_host_profiles` 见 `:97-100`、`:434-450`、`:724-726`
-   它甚至在结尾明确要求再补两份配套文档才可继续推进：`:780-788`

风险：

-   虽然它在目录里，但它不是当前可直接落代码的正式基线。
-   如果后续有人把它当作“AI 症状架构正式版”，会把旧表名和旧闭环重新带回来。

建议：

-   给文件头部补一个更强的 warning，说明它仅供历史架构草案参考。
-   或直接移动到 `archive/` / `drafts/`，避免与正式基线并列。

---

## 建议的收口顺序

1.  先修正 `当前正式基线文档清单`，让引用关系恢复可信。
2.  再补桥接文档，或声明它们已被哪些文档吸收。
3.  明确 runtime persistence policy。
4.  冻结 AI 入口新增字段的正式 SQL 方案。
5.  统一 `taxonomy_match_status` / `identity_resolution_status` / `family_name*` 等关键字段边界。
6.  最后再重画流程图和更新 SVG，确保图与正文一致。
