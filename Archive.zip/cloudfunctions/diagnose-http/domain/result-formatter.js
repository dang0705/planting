'use strict'

const { ranking: rankingConfig } = require('../constants/scoring')
const {
  toProblemId,
  toQuestionId,
  toOptionId,
  toResultId
} = require('../mappers/public-id-mapper')

function roundValue(value, digits = 4) {
  return Number(Number(value || 0).toFixed(digits))
}

function pickPrimaryRanking(rankings = [], problemMap = new Map()) {
  const allowedRoles = new Set(rankingConfig.supportRolesAsTop1)
  for (const item of rankings || []) {
    const problem = problemMap.get(item.problemKey)
    const role = problem?.problemRole || ''
    if (allowedRoles.has(role)) return item
  }
  return null
}

function buildExplanation(problem, explanationRow) {
  return {
    whyItHappens:
      explanationRow?.whyItHappensCn ||
      problem?.userDefinitionCn ||
      problem?.definition ||
      '',
    whatToCheckNext: explanationRow?.whatToCheckNextCn || '',
    firstAid:
      explanationRow?.firstAidCn ||
      problem?.userActionCn ||
      problem?.defaultAction ||
      '',
    avoid:
      explanationRow?.avoidCn ||
      problem?.userPreventionCn ||
      problem?.defaultPrevention || '',
    reassurance: explanationRow?.reassuranceCn || ''
  }
}

function mapSeverity(problem) {
  return (problem?.severityHintCn || '中').includes('高') ? 'high' : 'medium'
}

function mapUrgency(problem) {
  return (problem?.urgencyHintCn || '中').includes('高') ? 'high' : 'medium'
}

function buildLowConfidenceSummary(displayName, baseSummary, lowConfidence = {}) {
  if (!displayName) {
    return lowConfidence?.isLowConfidence ? '当前证据不足，暂时无法稳定判断。' : baseSummary
  }

  if (!lowConfidence?.isLowConfidence) {
    return baseSummary
  }

  return `当前更像 ${displayName}，但还不够确定。${baseSummary ? ` ${baseSummary}` : ''}`.trim()
}

function formatDiagnosisResponse({
  sessionId,
  round = 1,
  stage,
  observedSymptoms = [],
  rankings = [],
  followUps = [],
  problems = [],
  explanations = [],
  causality = [],
  plantId,
  followUpRequired = false,
  lowConfidence = { isLowConfidence: false, reasons: [], advice: [] }
}) {
  const problemMap = new Map((problems || []).map(item => [item.problemKey, item]))
  const explanationMap = new Map((explanations || []).map(item => [item.problemKey, item]))

  const primary = pickPrimaryRanking(rankings, problemMap)
  const primaryProblem = primary ? problemMap.get(primary.problemKey) : null
  const primaryExplanation = primary ? explanationMap.get(primary.problemKey) : null

  const contributingRoles = new Set(rankingConfig.contributingRoles)
  const intermediateRoles = new Set(rankingConfig.intermediateRoles)

  const contributingFactors = rankings
    .filter(item => {
      const role = problemMap.get(item.problemKey)?.problemRole || ''
      return contributingRoles.has(role)
    })
    .slice(0, 3)
    .map(item => ({
      factorId: `f_${item.problemKey}`,
      label: problemMap.get(item.problemKey)?.displayNameCn || item.problemCn || item.problemKey
    }))

  const intermediateStates = rankings
    .filter(item => {
      const role = problemMap.get(item.problemKey)?.problemRole || ''
      return intermediateRoles.has(role)
    })
    .slice(0, 3)
    .map(item => ({
      stateId: `s_${item.problemKey}`,
      label: problemMap.get(item.problemKey)?.displayNameCn || item.problemCn || item.problemKey
    }))

  const resultId = toResultId(sessionId, round)

  const baseSummaryText =
    primaryExplanation?.resultSummaryCn ||
    primaryProblem?.userDefinitionCn ||
    primaryProblem?.definition ||
    (primary ? `当前更像是 ${primary.problemCn || primary.problemKey}` : '暂无结论')
  const summaryText = buildLowConfidenceSummary(
    primaryProblem?.displayNameCn || primary?.problemCn || primary?.problemKey || '',
    baseSummaryText,
    lowConfidence
  )

  return {
    diagnosisSessionId: sessionId,
    roundId: `round_${round}`,
    stage,
    observedSymptoms,
    rankings: rankings.map(item => ({
      problemId: toProblemId(item.problemKey),
      problemKey: item.problemKey,
      problemCn: item.problemCn,
      role: problemMap.get(item.problemKey)?.problemRole || '',
      finalScore: roundValue(item.finalScore),
      baseScore: roundValue(item.baseScore),
      rankNo: item.rankNo
    })),
    topProblem: primary
      ? {
          problemId: toProblemId(primary.problemKey),
          problemKey: primary.problemKey,
          displayName:
            primaryProblem?.displayNameCn ||
            primary.problemCn ||
            primary.problemKey,
          summary: summaryText,
          severity: mapSeverity(primaryProblem),
          urgency: mapUrgency(primaryProblem)
        }
      : null,
    finalResult: primary
      ? {
          resultId,
          problemId: toProblemId(primary.problemKey),
          displayName:
            primaryProblem?.displayNameCn ||
            primary.problemCn ||
            primary.problemKey,
          summary: summaryText,
          severity: mapSeverity(primaryProblem),
          urgency: mapUrgency(primaryProblem)
        }
      : null,
    followUpRequired: Boolean(followUpRequired && followUps.length),
    followUps: followUps.map(question => ({
      questionId: toQuestionId(question.questionKey),
      questionKey: question.questionKey,
      targetSymptomKey: question.targetSymptomKey || '',
      questionGroupKey: question.questionGroupKey,
      type: 'single_choice',
      text: question.questionText,
      helpText: question.helpText,
      options: question.options.map(option => ({
        optionId: toOptionId(option.optionKey),
        optionKey: option.optionKey,
        text: option.text
      }))
    })),
    contributingFactors,
    intermediateStates,
    problemCausality: causality,
    resultExplanation: buildExplanation(primaryProblem, primaryExplanation),
    explanation: buildExplanation(primaryProblem, primaryExplanation),
    nextSteps: [
      ...(Array.isArray(lowConfidence?.advice)
        ? lowConfidence.advice.map((text, index) => ({
            stepId: `low_conf_${index + 1}`,
            text
          }))
        : []),
      {
        stepId: 'step_1',
        text:
          buildExplanation(primaryProblem, primaryExplanation).firstAid ||
          '先处理最明显的问题，再观察 3-7 天变化。'
      }
    ],
    whatToAvoid: buildExplanation(primaryProblem, primaryExplanation).avoid
      ? [buildExplanation(primaryProblem, primaryExplanation).avoid]
      : [],
    confidenceLevel: lowConfidence?.isLowConfidence ? 'low' : 'normal',
    confidenceReasons: Array.isArray(lowConfidence?.reasons) ? lowConfidence.reasons : [],
    needHumanReview: Boolean(lowConfidence?.isLowConfidence),
    plantId,
    resultId,
    timestamp: Date.now()
  }
}

module.exports = {
  formatDiagnosisResponse
}
