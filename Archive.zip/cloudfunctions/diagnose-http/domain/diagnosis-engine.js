'use strict'

const { clamp01 } = require('../repositories/sql')
const {
  evidence: evidenceConfig,
  ranking: rankingConfig,
  lowConfidence: lowConfidenceConfig
} = require('../constants/scoring')
const {
  resolvePlantContext,
  getCandidateProblemPriors,
  getGenusCandidatePriors,
  getHostCandidatePriors,
  getGenusCompatibilityMap,
  getHostCompatibilityMap
} = require('../repositories/prior-repository')
const { getProblemsByKeys, getExplanationsByProblemKeys } = require('../repositories/problem-repository')
const {
  getSymptomDictionary,
  getSymptomsByKeys,
  getEvidenceEdges
} = require('../repositories/symptom-repository')
const {
  getQuestionStrategies,
  getQuestionsByKeys,
  getQuestionOptionMappings
} = require('../repositories/question-repository')
const { getCausalityEdges } = require('../repositories/causality-repository')
const {
  computeVisualEvidenceScores,
  computeQuestionEvidenceAndPenalty
} = require('./evidence-scoring')
const { computeGenusFactor, computeHostFactor } = require('./prior-scorers')
const { computeCausalityBoosts } = require('./causality-scorer')
const { selectFollowUpQuestions } = require('./question-selector')
const { formatDiagnosisResponse } = require('./result-formatter')

function roundNum(value, digits = 6) {
  return Number(Number(value || 0).toFixed(digits))
}

function mapByKey(list = [], key = 'problemKey') {
  const map = new Map()
  for (const item of list || []) {
    const id = item?.[key]
    if (!id) continue
    map.set(id, item)
  }
  return map
}

function mergeObservedSymptoms(primary = [], extra = []) {
  const map = new Map()
  const merged = [...(primary || []), ...(extra || [])]
  for (const item of merged) {
    const key = String(item?.symptomKey || '').trim()
    if (!key) continue
    const current = map.get(key)
    if (!current || Number(item.confidence || 0) > Number(current.confidence || 0)) {
      map.set(key, {
        symptomKey: key,
        symptomCn: item.symptomCn || current?.symptomCn || key,
        confidence: clamp01(item.confidence ?? current?.confidence ?? 0.7),
        source: item.source || current?.source || 'visual_ai'
      })
    }
  }
  return Array.from(map.values())
}

function resolveReliabilityScore(rankings = []) {
  const top = rankings[0]
  const second = rankings[1] || { finalScore: 0 }
  if (!top) return 0

  const scoreGap = Math.max(Number(top.finalScore || 0) - Number(second.finalScore || 0), 0)
  const base = 1 - Math.exp(-Math.max(Number(top.finalScore || 0), 0))
  const gapBonus = Math.min(scoreGap, 1) * 0.35
  return clamp01(base * 0.7 + gapBonus)
}

function mergeCandidatePriors(...groups) {
  const merged = new Map()

  for (const group of groups) {
    for (const item of group || []) {
      if (!item?.problemKey) continue
      const existing = merged.get(item.problemKey) || {
        problemKey: item.problemKey,
        genusCompatibility: null,
        hostCompatibility: null,
        finalPriorScore: 0,
        matchedHostLevel: '',
        sourceLayer: '',
        dataStatus: item.dataStatus || 'partial'
      }

      merged.set(item.problemKey, {
        ...existing,
        genusCompatibility:
          item.genusCompatibility ?? existing.genusCompatibility,
        hostCompatibility:
          item.hostCompatibility ?? existing.hostCompatibility,
        finalPriorScore: Math.max(
          Number(existing.finalPriorScore || 0),
          Number(item.finalPriorScore || 0)
        ),
        matchedHostLevel: item.matchedHostLevel || existing.matchedHostLevel || '',
        sourceLayer: item.sourceLayer || existing.sourceLayer || '',
        dataStatus: item.dataStatus || existing.dataStatus || 'partial'
      })
    }
  }

  return Array.from(merged.values()).sort(
    (a, b) => Number(b.finalPriorScore || 0) - Number(a.finalPriorScore || 0)
  )
}

function buildLowConfidenceAdvice({ observedSymptoms = [], unknownCountByGroup = {}, noHighValueQuestion = false } = {}) {
  const advice = []

  if (noHighValueQuestion) {
    advice.push('当前缺少高价值问诊题，建议补拍整株、病斑特写、叶背和盆土照片后重新开始诊断。')
  }

  if ((observedSymptoms || []).length === 0) {
    advice.push('当前可用症状较少，建议在自然光下重新拍摄受损部位和整株照片。')
  }

  if (Object.values(unknownCountByGroup || {}).some(value => Number(value || 0) >= lowConfidenceConfig.unknownGroupThreshold)) {
    advice.push('已有多个关键问题无法确认，建议重点检查叶背、根部、盆土表面或虫体。')
  }

  if (!advice.length) {
    advice.push('当前证据仍不够稳定，建议补查叶背、根部、盆土状态，必要时重新开始诊断。')
  }

  return Array.from(new Set(advice))
}

function resolveLowConfidenceState({
  rankings = [],
  observedSymptoms = [],
  unknownCountByGroup = {},
  noHighValueQuestion = false
} = {}) {
  const topScore = Number(rankings[0]?.finalScore || 0)
  const secondScore = Number(rankings[1]?.finalScore || 0)
  const scoreGap = Math.max(topScore - secondScore, 0)
  const maxVisualConfidence = Math.max(
    0,
    ...(observedSymptoms || []).map(item => Number(item?.confidence || 0))
  )
  const unknownGroupCount = Object.values(unknownCountByGroup || {}).filter(
    value => Number(value || 0) >= lowConfidenceConfig.unknownGroupThreshold
  ).length

  const reasons = []
  if (topScore < lowConfidenceConfig.topScoreThreshold) reasons.push('top_score_low')
  if (scoreGap < lowConfidenceConfig.scoreGapThreshold) reasons.push('score_gap_small')
  if (unknownGroupCount > 0) reasons.push('too_many_unknowns')
  if ((observedSymptoms || []).length > 0 && maxVisualConfidence < lowConfidenceConfig.visualConfidenceThreshold) {
    reasons.push('visual_confidence_low')
  }
  if (noHighValueQuestion) reasons.push('no_high_value_questions')

  return {
    isLowConfidence: reasons.length > 0,
    reasons,
    advice: buildLowConfidenceAdvice({
      observedSymptoms,
      unknownCountByGroup,
      noHighValueQuestion
    })
  }
}

async function buildCandidatePriors(plantContext, observedSymptoms = [], { round = 1, stage = 'preliminary' } = {}) {
  const symptomKeys = Array.from(
    new Set((observedSymptoms || []).map(item => String(item?.symptomKey || '').trim()).filter(Boolean))
  )

  const plantPriors = await getCandidateProblemPriors(plantContext)
  const genusPriors = await getGenusCandidatePriors(plantContext.genus)
  const hostPriors = await getHostCandidatePriors({
    genus: plantContext.genus,
    family: plantContext.family,
    category: plantContext.category
  })
  const evidenceEdges = symptomKeys.length
    ? await getEvidenceEdges({ symptomKeys })
    : []

  const evidenceOnlyPriors = Array.from(
    new Set((evidenceEdges || []).map(item => item.problemKey).filter(Boolean))
  ).map(problemKey => ({
    problemKey,
    genusCompatibility: null,
    hostCompatibility: null,
    finalPriorScore: 0.35,
    matchedHostLevel: '',
    sourceLayer: 'evidence_hit',
    dataStatus: 'partial'
  }))

  const merged = mergeCandidatePriors(
    plantPriors,
    genusPriors,
    hostPriors,
    evidenceOnlyPriors
  )

  if (Number(round || 1) <= 1 && stage !== 'followup') {
    return merged
  }

  const baseProblemKeys = merged.map(item => item.problemKey)
  const causalityEdges = baseProblemKeys.length ? await getCausalityEdges(baseProblemKeys) : []
  const causalLinkedPriors = Array.from(
    new Set(
      (causalityEdges || [])
        .flatMap(item => [item.causeProblemKey, item.effectProblemKey])
        .filter(Boolean)
    )
  )
    .filter(problemKey => !baseProblemKeys.includes(problemKey))
    .map(problemKey => ({
      problemKey,
      genusCompatibility: null,
      hostCompatibility: null,
      finalPriorScore: 0.2,
      matchedHostLevel: '',
      sourceLayer: 'causal_linked',
      dataStatus: 'partial'
    }))

  return mergeCandidatePriors(merged, causalLinkedPriors)
}

async function buildFollowUps({
  rankings = [],
  observedSymptoms = [],
  symptomDictionary = [],
  askedQuestionKeys = [],
  unknownCountByGroup = {}
} = {}) {
  const topProblemKeys = rankings.slice(0, 3).map(item => item.problemKey)
  if (!topProblemKeys.length) return []

  const strategies = await getQuestionStrategies(topProblemKeys)
  if (!strategies.length) return []

  const questionKeys = Array.from(new Set(strategies.map(item => item.questionKey).filter(Boolean)))
  const questions = await getQuestionsByKeys(questionKeys)
  const optionMappings = await getQuestionOptionMappings(questionKeys)

  return selectFollowUpQuestions({
    rankings,
    strategies,
    questions,
    optionMappings,
    observedSymptoms: (observedSymptoms || []).map(item => {
      const symptomMeta = (symptomDictionary || []).find(row => row.symptomKey === item?.symptomKey)
      return {
        ...item,
        signalReliability: Number(symptomMeta?.signalReliability || 0)
      }
    }),
    askedQuestionKeys,
    unknownCountByGroup,
    maxQuestions: rankingConfig.maxQuestionsPerRound
  })
}

function collectMappedSymptomKeysFromAnswers(answers = [], optionMappings = []) {
  const answerKeySet = new Set(
    (answers || []).map(item => `${item.questionKey}::${item.optionKey}`)
  )
  return optionMappings
    .filter(item => answerKeySet.has(`${item.questionKey}::${item.optionKey}`))
    .map(item => item.mapsToSymptomKey)
    .filter(Boolean)
}

function toLegacyCompatiblePayload(publicResponse = {}) {
  const topProblem = publicResponse.topProblem || null
  return {
    diagnosisId: publicResponse.diagnosisSessionId,
    healthScore: null,
    healthStatus: topProblem ? 'warning' : 'unknown',
    mainIssue: topProblem?.displayName || '',
    finalProblemKey: topProblem?.problemKey || null,
    finalProblemCn: topProblem?.displayName || '',
    summary: topProblem?.summary || '',
    observedSymptoms: publicResponse.observedSymptoms || [],
    rankings: (publicResponse.rankings || []).map((item, index) => ({
      problemKey: item.problemKey,
      problemCn: item.problemCn || item.problemKey,
      weightedScore: item.finalScore,
      rankNo: index + 1,
      finalScore: item.finalScore
    })),
    needsFollowUp: Boolean(publicResponse.followUpRequired),
    followUps: (publicResponse.followUps || []).map(item => ({
      questionKey: item.questionKey,
      questionText: item.text,
      questionGroupKey: item.questionGroupKey,
      options: item.options || []
    })),
    problemCausality: publicResponse.problemCausality || [],
    reliabilityScore: 0,
    resultExplanation: publicResponse.resultExplanation || {}
  }
}

async function runDiagnosisRound({
  openid,
  plantId = null,
  userPlantId = null,
  lockedPlantContext = null,
  observedSymptoms = [],
  answers = [],
  askedQuestionKeys = [],
  unknownCountByGroup = {},
  round = 1,
  stage = 'preliminary',
  sessionId
}) {
  const plantContext = lockedPlantContext
    ? {
        userPlantId: lockedPlantContext.userPlantId || userPlantId || null,
        plantId: lockedPlantContext.plantId || plantId || null,
        plantDisplayName: lockedPlantContext.plantDisplayName || '未知植物',
        genus: lockedPlantContext.genus || '',
        family: lockedPlantContext.family || '',
        category: lockedPlantContext.category || ''
      }
    : await resolvePlantContext({ openid, plantId, userPlantId })
  const candidatePriors = await buildCandidatePriors(plantContext, observedSymptoms, { round, stage })
  const candidateProblemKeys = candidatePriors.map(item => item.problemKey)

  if (!candidateProblemKeys.length) {
    return {
      diagnosisSessionId: sessionId,
      roundId: `round_${round}`,
      stage: 'failed',
      observedSymptoms,
      rankings: [],
      topProblem: null,
      finalResult: null,
      followUpRequired: false,
      followUps: [],
      contributingFactors: [],
      intermediateStates: [],
      resultExplanation: {
        whyItHappens: '当前植物缺少可用规则数据，建议补充更多图片后重试。',
        whatToCheckNext: '',
        firstAid: '',
        avoid: '',
        reassurance: ''
      },
      legacyDiagnosis: {
        diagnosisId: sessionId,
        needsFollowUp: false,
        rankings: [],
        observedSymptoms
      },
      metrics: {
        reliabilityScore: 0
      },
      plantContext
    }
  }

  const questionKeys = Array.from(new Set((answers || []).map(item => item.questionKey).filter(Boolean)))
  const optionMappings = questionKeys.length
    ? await getQuestionOptionMappings(questionKeys)
    : []

  const mappedSymptomKeys = collectMappedSymptomKeysFromAnswers(answers, optionMappings)
  const symptomKeys = Array.from(
    new Set([
      ...(observedSymptoms || []).map(item => item.symptomKey),
      ...mappedSymptomKeys
    ].filter(Boolean))
  )

  const symptomRows = symptomKeys.length
    ? await getSymptomsByKeys(symptomKeys)
    : await getSymptomDictionary()
  const evidenceEdges = symptomKeys.length
    ? await getEvidenceEdges({ symptomKeys, problemKeys: candidateProblemKeys })
    : []
  const problems = await getProblemsByKeys(candidateProblemKeys)

  const symptomMap = mapByKey(symptomRows, 'symptomKey')
  const priorMap = mapByKey(candidatePriors, 'problemKey')

  const visualScores = computeVisualEvidenceScores({
    candidateProblemKeys,
    observedSymptoms,
    symptomDictionary: symptomRows,
    evidenceEdges
  })

  const { questionScores, penalties, answerEffects } = computeQuestionEvidenceAndPenalty({
    answers,
    optionMappings,
    candidateProblemKeys,
    symptomDictionary: symptomRows,
    evidenceEdges
  })

  const fallbackGenusMap = await getGenusCompatibilityMap(
    plantContext.genus,
    candidateProblemKeys
  )
  const fallbackHostMap = await getHostCompatibilityMap(
    {
      genus: plantContext.genus,
      family: plantContext.family,
      category: plantContext.category
    },
    candidateProblemKeys
  )

  let rankings = candidateProblemKeys.map(problemKey => {
    const prior = priorMap.get(problemKey) || {}
    const genusCompatibility =
      Number(prior.genusCompatibility ?? fallbackGenusMap[problemKey] ?? 0.5)
    const hostCompatibility =
      Number(prior.hostCompatibility ?? fallbackHostMap[problemKey]?.hostCompatibility ?? 1)

    const visualEvidence = Number(visualScores[problemKey] || 0)
    const questionEvidence = Number(questionScores[problemKey] || 0)
    const penalty = Number(penalties[problemKey] || 0)

    const totalEvidence = visualEvidence + evidenceConfig.questionWeight * questionEvidence
    const baseScore =
      totalEvidence *
        computeGenusFactor(genusCompatibility) *
        computeHostFactor(hostCompatibility) -
      penalty

    const problem = problems.find(item => item.problemKey === problemKey)

    return {
      problemKey,
      problemCn: problem?.problemCn || problemKey,
      problemRole: problem?.problemRole || 'root_cause',
      visualEvidence: roundNum(visualEvidence),
      questionEvidence: roundNum(questionEvidence),
      penalty: roundNum(penalty),
      totalEvidence: roundNum(totalEvidence),
      genusCompatibility: roundNum(genusCompatibility),
      hostCompatibility: roundNum(hostCompatibility),
      baseScore: roundNum(baseScore),
      finalScore: roundNum(baseScore)
    }
  })

  rankings = rankings.sort((a, b) => b.baseScore - a.baseScore)

  const allowCausalityBoost = Number(round || 1) > 1 || stage === 'followup'
  const causalityEdges = allowCausalityBoost
    ? await getCausalityEdges(rankings.slice(0, 3).map(item => item.problemKey))
    : []
  const causalityBoosts = allowCausalityBoost
    ? computeCausalityBoosts(rankings, causalityEdges)
    : {}

  rankings = rankings
    .map(item => {
      const causalityBoost = roundNum(causalityBoosts[item.problemKey] || 0)
      return {
        ...item,
        causalityBoost,
        finalScore: roundNum(item.baseScore + causalityBoost)
      }
    })
    .sort((a, b) => b.finalScore - a.finalScore)
    .map((item, index) => ({ ...item, rankNo: index + 1 }))

  const reliabilityScore = resolveReliabilityScore(rankings)
  const scoreGap = rankings.length > 1 ? rankings[0].finalScore - rankings[1].finalScore : rankings[0]?.finalScore || 0

  const hasEligibleTop1 = rankings.some(item =>
    rankingConfig.supportRolesAsTop1.includes(String(item.problemRole || '').trim())
  )

  const shouldAskFollowUp =
    round < rankingConfig.maxRounds &&
    (
      !hasEligibleTop1 ||
      Number(rankings[0]?.finalScore || 0) < rankingConfig.followUpTopScoreThreshold ||
      Number(scoreGap || 0) < rankingConfig.followUpGapThreshold
    )

  const mappedPositiveSymptoms = answerEffects
    .filter(item => item.effectType === 'positive' && item.mappedSymptomKey)
    .map(item => {
      const symptomMeta = symptomMap.get(item.mappedSymptomKey)
      return {
        symptomKey: item.mappedSymptomKey,
        symptomCn: symptomMeta?.displayTextCn || symptomMeta?.symptomCn || item.mappedSymptomKey,
        confidence: 1,
        source: 'follow_up_yes'
      }
    })

  const mergedObservedSymptoms = mergeObservedSymptoms(observedSymptoms, mappedPositiveSymptoms)
  const followUps = shouldAskFollowUp
    ? await buildFollowUps({
        rankings,
        observedSymptoms: mergedObservedSymptoms,
        symptomDictionary: symptomRows,
        askedQuestionKeys,
        unknownCountByGroup
      })
    : []

  const lowConfidence = resolveLowConfidenceState({
    rankings,
    observedSymptoms: mergedObservedSymptoms,
    unknownCountByGroup,
    noHighValueQuestion: Boolean(shouldAskFollowUp && followUps.length === 0)
  })
  const followUpRequired = Boolean(shouldAskFollowUp && followUps.length)
  const explanations = await getExplanationsByProblemKeys(rankings.slice(0, 5).map(item => item.problemKey))

  const stageFinal = followUpRequired ? 'followup' : 'final'

  const publicResponse = formatDiagnosisResponse({
    sessionId,
    round,
    stage: stageFinal,
    observedSymptoms: mergedObservedSymptoms,
    rankings,
    followUps,
    problems,
    explanations,
    causality: causalityEdges,
    plantId: plantContext.userPlantId || plantContext.plantId,
    followUpRequired,
    lowConfidence
  })

  return {
    ...publicResponse,
    metrics: {
      reliabilityScore: roundNum(reliabilityScore),
      topScoreGap: roundNum(scoreGap)
    },
    answerEffects,
    plantContext,
    legacyDiagnosis: toLegacyCompatiblePayload(publicResponse)
  }
}

module.exports = {
  runDiagnosisRound
}
