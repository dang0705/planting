'use strict'

const {
  jsonResponse,
  notFound,
  methodNotAllowed,
  getHttpRequestData,
  resolveRequestAppEnv,
  runWithRequestAppEnv,
  resolveHttpUserInfo
} = require('/opt/utils/http')
const { models } = require('/opt/utils/cloudbase')
const {
  listDiagnosisSessions,
  getDiagnosisSessionDetail
} = require('/opt/utils/plant-knowledge')

function fromBase64Url(value) {
  const normalized = String(value || '').replace(/-/g, '+').replace(/_/g, '/')
  const pad = normalized.length % 4 === 0 ? '' : '='.repeat(4 - (normalized.length % 4))
  return Buffer.from(`${normalized}${pad}`, 'base64').toString('utf8')
}

function parseResultId(resultId) {
  const full = String(resultId || '')
  if (!full.startsWith('r_')) return ''

  const decoded = fromBase64Url(full.slice(2))
  if (!decoded) return ''

  const [sessionId] = decoded.split(':')
  return sessionId || ''
}

function resolveDiagnosisId(query = {}) {
  return (
    String(query.id || '').trim() ||
    parseResultId(query.resultId || '') ||
    String(query.sessionId || '').trim()
  )
}

function mapSeverity(status = 'unknown') {
  return String(status || '').toLowerCase() === 'danger' ? 'high' : 'medium'
}

function toPublicHistoryList(data = {}) {
  const list = Array.isArray(data?.list) ? data.list : []
  return {
    items: list.map(item => ({
      historyId: item?._id || '',
      resultId: item?._id || '',
      createdAt: item?.createdAt || '',
      summary: {
        problemId: '',
        displayName: item?.mainIssue || '诊断记录',
        severity: mapSeverity(item?.healthStatus)
      }
    })),
    page: Number(data?.page || 1),
    pageSize: Number(data?.pageSize || 10),
    hasMore: Boolean(data?.hasMore)
  }
}

function toPublicHistoryDetail(detail = {}) {
  const diagnosisSessionId = String(detail?._id || detail?.diagnosisSessionId || '').trim()
  const summary = String(detail?.summary || '').trim()

  return {
    resultId: diagnosisSessionId,
    diagnosisSessionId,
    plantId: detail?.plantId || detail?.plantCatalogId || '',
    stage: detail?.needsFollowUp ? 'followup' : 'final',
    status: detail?.needsFollowUp ? 'active' : 'closed',
    finalResult: {
      problemId: '',
      displayName: detail?.finalProblemCn || '待进一步确认',
      summary,
      severity: mapSeverity(detail?.healthStatus),
      urgency: 'medium'
    },
    explanation: {
      whyItHappens: summary,
      whatToCheckNext: '',
      firstAid: detail?.treatment || '',
      avoid: detail?.prevention || ''
    },
    observedSymptoms: Array.isArray(detail?.symptoms)
      ? detail.symptoms.map(item => ({
          label: item?.symptomCn || '未命名症状',
          confidence: Number(item?.confidence || 0),
          source: item?.evidenceSource || 'history'
        }))
      : [],
    followUps: Array.isArray(detail?.followUps)
      ? detail.followUps.map(item => ({
          questionOrder: Number(item?.questionOrder || 0),
          text: item?.questionText || '',
          answerValue: item?.answerValue || '',
          status: item?.status || 'pending'
        }))
      : [],
    contributingFactors: [],
    intermediateStates: [],
    nextSteps: detail?.treatment ? [{ stepId: 'step_1', text: detail.treatment }] : [],
    whatToAvoid: detail?.prevention ? [detail.prevention] : [],
    timeline: {
      createdAt: detail?.createdAt || ''
    },
    versionMetadata: detail?.versionMetadata || {}
  }
}

async function getDiagnosisSnapshot(openid, diagnosisId) {
  try {
    const result = await models.$runSQL(
      `
        SELECT snapshot_json
        FROM diagnosis_result_snapshots
        WHERE diagnosis_id = {{diagnosisId}} AND _openid = {{openid}}
        LIMIT 1
      `,
      { diagnosisId, openid }
    )

    const snapshotText = result?.data?.executeResultList?.[0]?.snapshot_json
    if (!snapshotText) return null
    return JSON.parse(snapshotText)
  } catch (error) {
    console.warn('读取 diagnosis_result_snapshots 失败（已降级忽略）:', error.message)
    return null
  }
}

async function saveDiagnosisFeedback(openid, payload = {}) {
  const diagnosisId =
    parseResultId(payload.resultId || '') ||
    String(payload.diagnosisSessionId || payload.sessionId || payload.id || '').trim()

  if (!diagnosisId) {
    throw new Error('缺少 diagnosisId')
  }

  try {
    await models.$runSQL(
      `
        INSERT INTO diagnosis_feedback (
          _openid,
          diagnosis_id,
          is_helpful,
          is_accurate,
          note
        ) VALUES (
          {{openid}},
          {{diagnosisId}},
          {{isHelpful}},
          {{isAccurate}},
          {{note}}
        )
      `,
      {
        openid,
        diagnosisId,
        isHelpful: payload?.feedback?.isHelpful ? 1 : 0,
        isAccurate: payload?.feedback?.isAccurate ? 1 : 0,
        note: payload?.feedback?.note || ''
      }
    )
  } catch (error) {
    console.warn('写入 diagnosis_feedback 失败（已降级忽略）:', error.message)
  }

  return { ok: true }
}

async function main(event, context) {
  const request = getHttpRequestData(event, context)
  const path = String(request.path || '')
  const method = request.method || 'GET'

  try {
    if (path.includes('/diagnosis/history/health')) {
      return jsonResponse(200, { code: 200, data: { status: 'ok', timestamp: Date.now() } })
    }

    const authSource = method === 'GET' ? request.query : request.body
    const userInfo = await resolveHttpUserInfo(request.headers, authSource, context)
    if (!userInfo?.openid) {
      return jsonResponse(401, { code: 401, message: '请先登录', data: null })
    }

    if (path.includes('/diagnosis/history/detail')) {
      if (method !== 'GET') return methodNotAllowed(method)
      const diagnosisId = resolveDiagnosisId(request.query)
      const snapshot = diagnosisId ? await getDiagnosisSnapshot(userInfo.openid, diagnosisId) : null
      if (snapshot) {
        return jsonResponse(200, {
          code: 200,
          data: {
            resultId: diagnosisId,
            diagnosisSessionId: diagnosisId,
            plantId:
              snapshot?.plantContext?.userPlantId ||
              snapshot?.plantContext?.plantId ||
              '',
            stage: 'final',
            status: 'closed',
            finalResult: snapshot.finalResult || null,
            explanation: snapshot.explanation || {},
            contributingFactors: Array.isArray(snapshot.contributingFactors) ? snapshot.contributingFactors : [],
            intermediateStates: Array.isArray(snapshot.intermediateStates) ? snapshot.intermediateStates : [],
            confidenceLevel: snapshot.confidenceLevel || 'normal',
            needHumanReview: Boolean(snapshot.needHumanReview),
            nextSteps: Array.isArray(snapshot.nextSteps) ? snapshot.nextSteps : [],
            whatToAvoid: Array.isArray(snapshot.whatToAvoid) ? snapshot.whatToAvoid : [],
            followUps: Array.isArray(snapshot.askedQuestions) ? snapshot.askedQuestions : [],
            timeline: {
              createdAt: ''
            },
            versionMetadata: snapshot.versionMetadata || {}
          }
        })
      }
      const detail = await getDiagnosisSessionDetail(userInfo.openid, diagnosisId)
      if (!detail) {
        return jsonResponse(404, { code: 404, message: '诊断记录不存在', data: null })
      }
      return jsonResponse(200, { code: 200, data: toPublicHistoryDetail(detail) })
    }

    if (path.includes('/diagnosis/history/feedback')) {
      if (method !== 'POST') return methodNotAllowed(method)
      const data = await saveDiagnosisFeedback(userInfo.openid, request.body || {})
      return jsonResponse(200, { code: 200, data })
    }

    if (path.includes('/diagnosis/history')) {
      if (method !== 'GET') return methodNotAllowed(method)
      const data = await listDiagnosisSessions(userInfo.openid, {
        page: Number(request.query.page || 1),
        pageSize: Number(request.query.pageSize || 10),
        userPlantId: request.query.plantId || null
      })
      return jsonResponse(200, { code: 200, data: toPublicHistoryList(data) })
    }

    if (path.includes('/diagnosis/decision')) {
      return jsonResponse(410, {
        code: 410,
        message: '诊断决策接口已下线，请使用 diagnose-http 统一诊断链路',
        data: null
      })
    }

    return notFound(path)
  } catch (error) {
    console.error('diagnosis-history-http error:', error)
    return jsonResponse(500, { code: 500, message: error.message, data: null })
  }
}

module.exports.main = (event, context) => {
  const request = getHttpRequestData(event, context)
  const appEnv = resolveRequestAppEnv(request.headers, request.query, request.body)
  return runWithRequestAppEnv(appEnv, () => main(event, context))
}
