# v8：上下文预算优化版

## 目的

本包基于上传的 `AGENTS.md`、`ai-rules.zip`、`agents.zip` 重新整理，重点实现“输入上下文瘦身”：

1. Main agent 优先生成规则摘要。
2. Subagent 默认读取摘要、任务说明、handoff、diff，不重复读取源文档。
3. 单个 subagent 默认读取规则文件不超过 2 个。
4. 超过 2 个规则文件必须由 Dispatch Plan 说明原因。
5. 归档长文档、历史总结、完整避坑记录默认不读；只按章节、关键词或问题域读取。
6. 下游 agent 优先读取上游 agent 的摘要和 handoff，不重复读取源文档。
7. `AGENTS.md` 继续保持轻量入口，不承载长规则。

## 目录

```text
AGENTS.md
docs/ai-rules/*.md
.codex/agents/*.toml
codex-agents-visible/*.toml
```

## 使用建议

先备份：

```bash
mkdir -p _backup_agents_v8
cp AGENTS.md _backup_agents_v8/AGENTS.md 2>/dev/null || true
cp -R docs/ai-rules _backup_agents_v8/ai-rules 2>/dev/null || true
cp -R .codex/agents _backup_agents_v8/agents 2>/dev/null || true
```

再复制：

```bash
cp -R codex_context_budget_v8/. /你的项目根目录/
```

## 注意

`codex-agents-visible/` 只是可见备份，真正生效路径仍是 `.codex/agents/`。


## v9 大目录索引更新

本版基于 `codex_context_budget_v8.zip` 增加：

1. `docs/code-logics/INDEX.md`
2. `docs/new-rules/INDEX.md`
3. `docs/ai-rules/large-doc-index-read-policy.md`

核心规则：

- subagent 不得全量读取 `docs/code-logics/` 或 `docs/new-rules/`。
- 必须先读对应 `INDEX.md`。
- 每次默认只读取 1～2 个索引命中的具体文档。
- 下游 agent 优先读取上游摘要和 handoff，不重复读取源文档。


## v10 new-rules All-in-One 更新

本版基于 v9，替换 `docs/new-rules/` 的默认读取入口：

新增：

```text
docs/new-rules/planting_ai_diagnosis_source_index.json
docs/new-rules/planting_ai_diagnosis_all_in_one.md
```

更新策略：

1. `docs/new-rules/INDEX.md` 降级为跳转说明。
2. 默认先读 `planting_ai_diagnosis_source_index.json`。
3. 再读 `planting_ai_diagnosis_all_in_one.md` 第 0～15 章摘要区。
4. 只有需要原文核对时，才读附录 A 的指定 `Sxx`。
5. 禁止任何 subagent 默认全量读取 All-in-One 全文。
6. 原 48 份 Markdown 可归档，但不再作为默认读取入口。
