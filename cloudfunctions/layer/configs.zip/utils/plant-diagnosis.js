﻿'use strict'

const { models } = require('/opt/utils/cloudbase')
const { diagnosis: DIAGNOSIS_RULES } = require('/opt/configs')
const { buildDiagnosisDecision } = require('./plant-knowledge')

const SYMPTOM_CACHE_TTL = DIAGNOSIS_RULES.symptomCacheTtlMs
const symptomCache = {
  expiresAt: 0,
  list: []
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value))
}

function round(value, digits = 4) {
  return Number(Number(value || 0).toFixed(digits))
}

function normalizeText(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/\s+/g, '')
    .replace(/[，。；：、,.!?！？;:“”"'`~（）()【】\[\]<>《》\-_/]/g, '')
}

function uniqueBy(list, key) {
  const seen = new Set()
  return list.filter(item => {
    const currentKey = key(item)
    if (seen.has(currentKey)) {
      return false
    }
    seen.add(currentKey)
    return true
  })
}

function buildSymptomAliases(row) {
  const symptomCn = String(row.symptom_cn || '').trim()
  const aliases = new Set()

  if (symptomCn) {
    aliases.add(symptomCn)
    const simplified = symptomCn.replace(/^(叶片|叶面|叶背|叶缘|叶尖|新叶|老叶|根部|根系|茎部|茎基部|花朵|花瓣|花苞|枝条|盆土|土表|果实)/, '')
    if (simplified && simplified.length >= 2) {
      aliases.add(simplified)
    }
    if (symptomCn.length >= 4) {
      aliases.add(symptomCn.slice(-2))
      aliases.add(symptomCn.slice(-3))
    }
  }

  const note = String(row.note || '')
  for (const part of note.split(/[，、/,；;]/)) {
    const token = part.trim()
    if (token.length >= 2 && token.length <= 8 && /[\u4e00-\u9fa5]/.test(token)) {
      aliases.add(token)
    }
  }

  return Array.from(aliases)
    .map(item => item.trim())
    .filter(item => item.length >= 2 && /[\u4e00-\u9fa5]/.test(item))
    .sort((a, b) => b.length - a.length)
}

async function getSymptomDictionary() {
  const now = Date.now()
  if (symptomCache.expiresAt > now && symptomCache.list.length) {
    return symptomCache.list
  }

  const result = await models.$runSQL(
    `
      SELECT
        symptom_key,
        symptom_cn,
        location_key,
        symptom_type,
        base_evidence_weight,
        symptom_reliability,
        note
      FROM symptoms
      WHERE data_status = 'audited'
      ORDER BY base_evidence_weight DESC, symptom_reliability DESC, symptom_key ASC
    `,
    {}
  )

  symptomCache.list = (result?.data?.executeResultList || []).map(row => ({
    symptomKey: row.symptom_key,
    symptomCn: row.symptom_cn,
    locationKey: row.location_key || '',
    symptomType: row.symptom_type || '',
    baseEvidenceWeight: Number(row.base_evidence_weight || 0),
    symptomReliability: Number(row.symptom_reliability || 0),
    aliases: buildSymptomAliases(row)
  }))
  symptomCache.expiresAt = now + SYMPTOM_CACHE_TTL
  return symptomCache.list
}

function extractObservedSymptoms({ text = '', evidenceSource = 'llm' }, symptomDictionary) {
  const normalizedText = normalizeText(text)
  if (!normalizedText) {
    return []
  }

  const observations = []
  for (const symptom of symptomDictionary) {
    const matchedAlias = symptom.aliases.find(alias => normalizedText.includes(normalizeText(alias)))
    if (!matchedAlias) {
      continue
    }

    const aliasScore = clamp(
      normalizeText(matchedAlias).length / 8,
      DIAGNOSIS_RULES.aliasScoreMin,
      DIAGNOSIS_RULES.aliasScoreMax
    )
    const confidence = clamp(
      symptom.symptomReliability * 0.45 + symptom.baseEvidenceWeight * 0.35 + aliasScore,
      DIAGNOSIS_RULES.confidenceMin,
      DIAGNOSIS_RULES.confidenceMax
    )

    observations.push({
      symptomKey: symptom.symptomKey,
      symptomCn: symptom.symptomCn,
      locationKey: symptom.locationKey,
      confidence: round(confidence),
      evidenceSource
    })
  }

  return uniqueBy(
    observations.sort((a, b) => b.confidence - a.confidence || a.symptomKey.localeCompare(b.symptomKey)),
    item => item.symptomKey
  )
}

function mergeObservedSymptoms(...groups) {
  const merged = new Map()
  for (const group of groups) {
    for (const item of group || []) {
      if (!item?.symptomKey) continue
      const current = merged.get(item.symptomKey)
      if (!current || Number(item.confidence || 0) > Number(current.confidence || 0)) {
        merged.set(item.symptomKey, {
          symptomKey: item.symptomKey,
          symptomCn: item.symptomCn,
          locationKey: item.locationKey || '',
          confidence: round(item.confidence || 0),
          evidenceSource: item.evidenceSource || current?.evidenceSource || 'llm'
        })
      }
    }
  }

  return Array.from(merged.values()).sort(
    (a, b) => b.confidence - a.confidence || a.symptomKey.localeCompare(b.symptomKey)
  )
}

function mapHealthScore(topScore, reliabilityScore, needsFollowUp) {
  const certaintyPenalty =
    topScore * DIAGNOSIS_RULES.healthScoreTopWeight +
    reliabilityScore * DIAGNOSIS_RULES.healthScoreReliabilityWeight
  const followUpPenalty = needsFollowUp ? DIAGNOSIS_RULES.healthScoreFollowUpPenalty : 0
  return clamp(100 - Math.round(certaintyPenalty + followUpPenalty), 18, 92)
}

function mapHealthStatus(healthScore) {
  if (healthScore >= DIAGNOSIS_RULES.healthScoreHealthyThreshold) return 'healthy'
  if (healthScore >= DIAGNOSIS_RULES.healthScoreWarningThreshold) return 'warning'
  return 'sick'
}

function joinProblemActions(problem, baseResult) {
  const actions = [problem?.default_action, baseResult?.treatment]
    .map(item => String(item || '').trim())
    .filter(Boolean)
  return uniqueBy(actions, item => item).join('\n')
}

function joinProblemPreventions(problem, baseResult) {
  const items = [problem?.default_prevention, baseResult?.prevention]
    .map(item => String(item || '').trim())
    .filter(Boolean)
  return uniqueBy(items, item => item).join('\n')
}

function buildSummary({
  problemCn,
  reliabilityScore,
  needsFollowUp,
  observedSymptoms,
  followUps,
  baseSummary
}) {
  const symptomText = observedSymptoms.slice(0, DIAGNOSIS_RULES.followUpMaxQuestions).map(item => item.symptomCn).join('、')
  const reliabilityText = `可信度 ${Math.round((reliabilityScore || 0) * 100)}%`
  const parts = []

  if (problemCn) {
    parts.push(`当前最可能问题为${problemCn}`)
  }
  if (symptomText) {
    parts.push(`已识别症状：${symptomText}`)
  }
  parts.push(reliabilityText)

  if (needsFollowUp && followUps.length) {
    parts.push(`还需确认 ${followUps.length} 个关键症状后再收敛结论`)
  } else if (!needsFollowUp) {
    parts.push('当前证据已足够，无需继续问诊')
  }

  const summary = parts.join('。')
  if (summary.length >= 24) {
    return `${summary}。`
  }
  return baseSummary || summary
}

async function loadProblemProfile(problemKey) {
  if (!problemKey) {
    return null
  }

  const result = await models.$runSQL(
    `
      SELECT
        problem_key,
        problem_cn,
        problem_type,
        definition,
        default_action,
        default_prevention
      FROM problems
      WHERE problem_key = {{problemKey}}
      LIMIT 1
    `,
    { problemKey }
  )

  const row = result?.data?.executeResultList?.[0]
  if (!row) {
    return null
  }

  return {
    problemKey: row.problem_key,
    problemCn: row.problem_cn || row.problem_key,
    problemType: row.problem_type || '',
    definition: row.definition || '',
    defaultAction: row.default_action || '',
    defaultPrevention: row.default_prevention || ''
  }
}

async function buildStructuredDiagnosis({
  openid,
  plantId = null,
  userPlantId = null,
  diagnosisText = '',
  description = '',
  baseResult = {},
  mode = 'quick'
}) {
  const symptomDictionary = await getSymptomDictionary()
  const extractedFromDiagnosis = extractObservedSymptoms(
    { text: diagnosisText, evidenceSource: 'llm' },
    symptomDictionary
  )
  const extractedFromDescription = extractObservedSymptoms(
    { text: description, evidenceSource: 'user_text' },
    symptomDictionary
  )
  const observedSymptoms = mergeObservedSymptoms(extractedFromDiagnosis, extractedFromDescription)

  if (!observedSymptoms.length) {
    return {
      ...baseResult,
      diagnosisMode: mode,
      observedSymptoms: [],
      rankings: [],
      followUps: [],
      topProblemKey: baseResult.topProblemKey || null,
      topProblemScore: baseResult.topProblemScore || null,
      reliabilityScore: baseResult.reliabilityScore || 0,
      needsFollowUp: false,
      finalProblemKey: baseResult.finalProblemKey || null,
      finalProblemCn: baseResult.finalProblemCn || baseResult.mainIssue || null
    }
  }

  const decision = await buildDiagnosisDecision({
    openid,
    plantId,
    userPlantId,
    observedSymptoms
  })
  const topRanking = decision.rankings[0]
  if (!topRanking) {
    return {
      ...baseResult,
      diagnosisMode: mode,
      observedSymptoms,
      rankings: [],
      followUps: [],
      reliabilityScore: 0,
      needsFollowUp: false
    }
  }

  const problem = await loadProblemProfile(topRanking.problemKey)
  const needsFollowUp = Boolean(decision.needsFollowUp && decision.followUps.length > 0)
  const healthScore = mapHealthScore(
    Number(topRanking.weightedScore || 0),
    Number(decision.reliabilityScore || 0),
    needsFollowUp
  )
  const healthStatus = mapHealthStatus(healthScore)

  return {
    ...baseResult,
    diagnosisMode: mode,
    mainIssue: problem?.problemCn || topRanking.problemCn || baseResult.mainIssue,
    symptoms: observedSymptoms.map(item => item.symptomCn).join('、') || baseResult.symptoms || '',
    treatment: joinProblemActions(problem, baseResult),
    prevention: joinProblemPreventions(problem, baseResult),
    summary: buildSummary({
      problemCn: problem?.problemCn || topRanking.problemCn,
      reliabilityScore: decision.reliabilityScore,
      needsFollowUp,
      observedSymptoms,
      followUps: decision.followUps,
      baseSummary: baseResult.summary
    }),
    healthScore,
    healthStatus,
    problemType: problem?.problemType || topRanking.problemType || '',
    topProblemKey: topRanking.problemKey,
    topProblemScore: round(topRanking.weightedScore),
    reliabilityScore: round(decision.reliabilityScore),
    needsFollowUp,
    finalProblemKey: topRanking.problemKey,
    finalProblemCn: problem?.problemCn || topRanking.problemCn,
    observedSymptoms,
    rankings: decision.rankings,
    followUps: decision.followUps,
    supportingSymptomCount: decision.supportingSymptomCount,
    decisiveSymptomCount: decision.decisiveSymptomCount,
    problemCausality: decision.problemCausality || []
  }
}

module.exports = {
  buildStructuredDiagnosis,
  extractObservedSymptoms,
  getSymptomDictionary
}
