const diagnose = {
  llm: {
    host: 'hunyuan.tencentcloudapi.com',
    model: 'hunyuan-vision',
    service: 'hunyuan',
    options: {
      TopP: 0.3,
      Temperature: 0.1,
      Seed: 42
    }
  },
  prompts: {
    llm: '',
    buildIdentifySymptomsPrompt(symptomList) {
      const numberedSymptoms = (symptomList || [])
        .map((symptom, index) => `${index + 1}. ${symptom}`)
        .join('\n')
      return `请仔细观察这张植物图片，从以下症状列表中选择1-5个最明显的症状：
        ${numberedSymptoms}
      要求：
      1. 只返回症状序号 index，不要返回症状ID，不要返回中文名称，不要解释
      2. 只允许从上面的症状列表中选择，不能发明新症状
      3. 按明显程度排序（最明显的在前）
      4. 最多返回5个症状
      5. 如果图片中没有明显症状，返回空数组
      6. 必须输出严格 JSON 数组，格式固定为：[{"index":1,"score":8},{"index":5,"score":6}]
      7. score 范围为 1 到 10，分数越高表示该症状越明显、初始匹配度越高
      
      示例输出：
      [{"index":1,"score":8},{"index":5,"score":6}]`
    },
    buildMatchSymptomPrompt(category, text) {
      return `任务：把用户描述映射到最可能的植物症状ID。

类别：${category?.label || ''}
用户描述：${text || ''}

可选症状：
${(category?.symptoms || []).map(item => `- ${item.id}: ${item.label}`).join('\n')}

要求：
1. 只能从可选症状中选择一个最可能的 symptomId
2. 如果完全无法判断，返回 {"symptomId":""}
3. 只输出严格 JSON，不要解释

示例：
{"symptomId":"yellow_leaves"}`
    }
  }
}

const payment = {
  routes: {
    createOrder: '/create-order',
    callback: '/pay-callback',
    health: '/health'
  },
  defaults: {
    appid: 'wx85bb3976301f75fb',
    currency: 'CNY',
    description: '植物服务订单',
    total: 1
  }
}

module.exports = {
  diagnose,
  payment,
  llm: diagnose.llm,
  prompts: diagnose.prompts
}
