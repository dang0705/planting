module.exports = {
  llm: {
    host: 'hunyuan.tencentcloudapi.com',
    model: 'hunyuan-vision',
    service: 'hunyuan'
  },
  diagnosis: {
    symptomCacheTtlMs: 5 * 60 * 1000,
    aliasScoreMin: 0.08,
    aliasScoreMax: 0.2,
    confidenceMin: 0.45,
    confidenceMax: 0.98,
    decisiveContributionThreshold: 0.12,
    decisiveAssociationStrength: 0.9,
    decisiveSymptomReliability: 0.8,
    decisiveHostCompatibility: 0.7,
    healthScoreTopWeight: 34,
    healthScoreReliabilityWeight: 20,
    healthScoreFollowUpPenalty: 6,
    healthScoreHealthyThreshold: 80,
    healthScoreWarningThreshold: 55,
    followUpTopScoreThreshold: 0.78,
    followUpScoreGapThreshold: 0.18,
    followUpSupportingSymptomThreshold: 2,
    followUpDecisiveSymptomThreshold: 1,
    followUpMaxQuestions: 3,
    reliabilityGapCap: 0.2,
    reliabilityGapFactor: 0.5
  },
  prompts: {
    llm: `请结合图片和症状描述输出诊断结论，必须使用中文，并严格按以下格式输出：
观察症状：尽量使用简短症状短语，多个用顿号分隔，例如 叶片发黄、叶缘焦枯、叶片萎蔫、细密蛛网、叶面红点、银色条纹、叶面黏液、煤污病、虫体聚集、根部发黑、茎基部软腐、盆土发霉。
主要问题：一句话概括最可能的问题。
处理建议：最多 3 条，每条不超过 16 个字。
预防建议：最多 2 条，每条不超过 16 个字。`
  }
}
